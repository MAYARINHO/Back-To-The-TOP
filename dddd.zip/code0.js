gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDPlayerObjects1= [];
gdjs.Game_32SceneCode.GDPlayerObjects2= [];
gdjs.Game_32SceneCode.GDPlayerObjects3= [];
gdjs.Game_32SceneCode.GDBackgroundObjects1= [];
gdjs.Game_32SceneCode.GDBackgroundObjects2= [];
gdjs.Game_32SceneCode.GDBackgroundObjects3= [];
gdjs.Game_32SceneCode.GDCoinsObjects1= [];
gdjs.Game_32SceneCode.GDCoinsObjects2= [];
gdjs.Game_32SceneCode.GDCoinsObjects3= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects3= [];
gdjs.Game_32SceneCode.GDLuckyBlockObjects1= [];
gdjs.Game_32SceneCode.GDLuckyBlockObjects2= [];
gdjs.Game_32SceneCode.GDLuckyBlockObjects3= [];
gdjs.Game_32SceneCode.GDStarObjects1= [];
gdjs.Game_32SceneCode.GDStarObjects2= [];
gdjs.Game_32SceneCode.GDStarObjects3= [];
gdjs.Game_32SceneCode.GDHudTextObjects1= [];
gdjs.Game_32SceneCode.GDHudTextObjects2= [];
gdjs.Game_32SceneCode.GDHudTextObjects3= [];
gdjs.Game_32SceneCode.GDGroundSolidObjects1= [];
gdjs.Game_32SceneCode.GDGroundSolidObjects2= [];
gdjs.Game_32SceneCode.GDGroundSolidObjects3= [];
gdjs.Game_32SceneCode.GDGordonObjects1= [];
gdjs.Game_32SceneCode.GDGordonObjects2= [];
gdjs.Game_32SceneCode.GDGordonObjects3= [];
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects1= [];
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects2= [];
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects3= [];
gdjs.Game_32SceneCode.GDHouseObjects1= [];
gdjs.Game_32SceneCode.GDHouseObjects2= [];
gdjs.Game_32SceneCode.GDHouseObjects3= [];
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects1= [];
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects2= [];
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects3= [];
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects1= [];
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects2= [];
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects3= [];
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects1= [];
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects2= [];
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects3= [];
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects1= [];
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects2= [];
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects3= [];
gdjs.Game_32SceneCode.GDBridgeObjects1= [];
gdjs.Game_32SceneCode.GDBridgeObjects2= [];
gdjs.Game_32SceneCode.GDBridgeObjects3= [];
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects1= [];
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects2= [];
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects3= [];
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects1= [];
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects2= [];
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects3= [];
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects1= [];
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects2= [];
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects3= [];
gdjs.Game_32SceneCode.GDLamp_9595leftObjects1= [];
gdjs.Game_32SceneCode.GDLamp_9595leftObjects2= [];
gdjs.Game_32SceneCode.GDLamp_9595leftObjects3= [];
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects1= [];
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects2= [];
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects3= [];
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects1= [];
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects2= [];
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects3= [];
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects1= [];
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects2= [];
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects3= [];
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects1= [];
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects2= [];
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects3= [];
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects1= [];
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects2= [];
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects3= [];
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects1= [];
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects2= [];
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects3= [];
gdjs.Game_32SceneCode.GDLamp_9595rightObjects1= [];
gdjs.Game_32SceneCode.GDLamp_9595rightObjects2= [];
gdjs.Game_32SceneCode.GDLamp_9595rightObjects3= [];
gdjs.Game_32SceneCode.GDMushroomsObjects1= [];
gdjs.Game_32SceneCode.GDMushroomsObjects2= [];
gdjs.Game_32SceneCode.GDMushroomsObjects3= [];
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects1= [];
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects2= [];
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects3= [];
gdjs.Game_32SceneCode.GDTile_959511Objects1= [];
gdjs.Game_32SceneCode.GDTile_959511Objects2= [];
gdjs.Game_32SceneCode.GDTile_959511Objects3= [];
gdjs.Game_32SceneCode.GDTile_95951Objects1= [];
gdjs.Game_32SceneCode.GDTile_95951Objects2= [];
gdjs.Game_32SceneCode.GDTile_95951Objects3= [];
gdjs.Game_32SceneCode.GDTile_959512Objects1= [];
gdjs.Game_32SceneCode.GDTile_959512Objects2= [];
gdjs.Game_32SceneCode.GDTile_959512Objects3= [];
gdjs.Game_32SceneCode.GDTile_959513Objects1= [];
gdjs.Game_32SceneCode.GDTile_959513Objects2= [];
gdjs.Game_32SceneCode.GDTile_959513Objects3= [];
gdjs.Game_32SceneCode.GDTile_959515Objects1= [];
gdjs.Game_32SceneCode.GDTile_959515Objects2= [];
gdjs.Game_32SceneCode.GDTile_959515Objects3= [];
gdjs.Game_32SceneCode.GDTile_959514Objects1= [];
gdjs.Game_32SceneCode.GDTile_959514Objects2= [];
gdjs.Game_32SceneCode.GDTile_959514Objects3= [];
gdjs.Game_32SceneCode.GDTile_959516Objects1= [];
gdjs.Game_32SceneCode.GDTile_959516Objects2= [];
gdjs.Game_32SceneCode.GDTile_959516Objects3= [];
gdjs.Game_32SceneCode.GDTile_959519Objects1= [];
gdjs.Game_32SceneCode.GDTile_959519Objects2= [];
gdjs.Game_32SceneCode.GDTile_959519Objects3= [];
gdjs.Game_32SceneCode.GDTile_959517Objects1= [];
gdjs.Game_32SceneCode.GDTile_959517Objects2= [];
gdjs.Game_32SceneCode.GDTile_959517Objects3= [];
gdjs.Game_32SceneCode.GDTile_959518Objects1= [];
gdjs.Game_32SceneCode.GDTile_959518Objects2= [];
gdjs.Game_32SceneCode.GDTile_959518Objects3= [];
gdjs.Game_32SceneCode.GDTile_95952Objects1= [];
gdjs.Game_32SceneCode.GDTile_95952Objects2= [];
gdjs.Game_32SceneCode.GDTile_95952Objects3= [];
gdjs.Game_32SceneCode.GDTile_959520Objects1= [];
gdjs.Game_32SceneCode.GDTile_959520Objects2= [];
gdjs.Game_32SceneCode.GDTile_959520Objects3= [];
gdjs.Game_32SceneCode.GDTile_959521Objects1= [];
gdjs.Game_32SceneCode.GDTile_959521Objects2= [];
gdjs.Game_32SceneCode.GDTile_959521Objects3= [];
gdjs.Game_32SceneCode.GDTile_959522Objects1= [];
gdjs.Game_32SceneCode.GDTile_959522Objects2= [];
gdjs.Game_32SceneCode.GDTile_959522Objects3= [];
gdjs.Game_32SceneCode.GDTile_959523Objects1= [];
gdjs.Game_32SceneCode.GDTile_959523Objects2= [];
gdjs.Game_32SceneCode.GDTile_959523Objects3= [];
gdjs.Game_32SceneCode.GDTile_959524Objects1= [];
gdjs.Game_32SceneCode.GDTile_959524Objects2= [];
gdjs.Game_32SceneCode.GDTile_959524Objects3= [];
gdjs.Game_32SceneCode.GDTile_959526Objects1= [];
gdjs.Game_32SceneCode.GDTile_959526Objects2= [];
gdjs.Game_32SceneCode.GDTile_959526Objects3= [];
gdjs.Game_32SceneCode.GDTile_959527Objects1= [];
gdjs.Game_32SceneCode.GDTile_959527Objects2= [];
gdjs.Game_32SceneCode.GDTile_959527Objects3= [];
gdjs.Game_32SceneCode.GDTile_959525Objects1= [];
gdjs.Game_32SceneCode.GDTile_959525Objects2= [];
gdjs.Game_32SceneCode.GDTile_959525Objects3= [];
gdjs.Game_32SceneCode.GDTile_959528Objects1= [];
gdjs.Game_32SceneCode.GDTile_959528Objects2= [];
gdjs.Game_32SceneCode.GDTile_959528Objects3= [];
gdjs.Game_32SceneCode.GDTile_959529Objects1= [];
gdjs.Game_32SceneCode.GDTile_959529Objects2= [];
gdjs.Game_32SceneCode.GDTile_959529Objects3= [];
gdjs.Game_32SceneCode.GDTile_959531Objects1= [];
gdjs.Game_32SceneCode.GDTile_959531Objects2= [];
gdjs.Game_32SceneCode.GDTile_959531Objects3= [];
gdjs.Game_32SceneCode.GDTile_959535Objects1= [];
gdjs.Game_32SceneCode.GDTile_959535Objects2= [];
gdjs.Game_32SceneCode.GDTile_959535Objects3= [];
gdjs.Game_32SceneCode.GDTile_959532Objects1= [];
gdjs.Game_32SceneCode.GDTile_959532Objects2= [];
gdjs.Game_32SceneCode.GDTile_959532Objects3= [];
gdjs.Game_32SceneCode.GDTile_959536Objects1= [];
gdjs.Game_32SceneCode.GDTile_959536Objects2= [];
gdjs.Game_32SceneCode.GDTile_959536Objects3= [];
gdjs.Game_32SceneCode.GDTile_959537Objects1= [];
gdjs.Game_32SceneCode.GDTile_959537Objects2= [];
gdjs.Game_32SceneCode.GDTile_959537Objects3= [];
gdjs.Game_32SceneCode.GDTile_95957Objects1= [];
gdjs.Game_32SceneCode.GDTile_95957Objects2= [];
gdjs.Game_32SceneCode.GDTile_95957Objects3= [];
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects1= [];
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects2= [];
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects3= [];
gdjs.Game_32SceneCode.GDTile_95958Objects1= [];
gdjs.Game_32SceneCode.GDTile_95958Objects2= [];
gdjs.Game_32SceneCode.GDTile_95958Objects3= [];
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects1= [];
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects2= [];
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects3= [];
gdjs.Game_32SceneCode.GDBatObjects1= [];
gdjs.Game_32SceneCode.GDBatObjects2= [];
gdjs.Game_32SceneCode.GDBatObjects3= [];
gdjs.Game_32SceneCode.GDTile_95959Objects1= [];
gdjs.Game_32SceneCode.GDTile_95959Objects2= [];
gdjs.Game_32SceneCode.GDTile_95959Objects3= [];
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects1= [];
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects2= [];
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects3= [];
gdjs.Game_32SceneCode.GDDark_9595GuardObjects1= [];
gdjs.Game_32SceneCode.GDDark_9595GuardObjects2= [];
gdjs.Game_32SceneCode.GDDark_9595GuardObjects3= [];
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects1= [];
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects2= [];
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects3= [];
gdjs.Game_32SceneCode.GDFrogObjects1= [];
gdjs.Game_32SceneCode.GDFrogObjects2= [];
gdjs.Game_32SceneCode.GDFrogObjects3= [];
gdjs.Game_32SceneCode.GDMushroomObjects1= [];
gdjs.Game_32SceneCode.GDMushroomObjects2= [];
gdjs.Game_32SceneCode.GDMushroomObjects3= [];
gdjs.Game_32SceneCode.GDNecromancerObjects1= [];
gdjs.Game_32SceneCode.GDNecromancerObjects2= [];
gdjs.Game_32SceneCode.GDNecromancerObjects3= [];
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects1= [];
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects2= [];
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects3= [];
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects1= [];
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects2= [];
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects3= [];


gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.Game_32SceneCode.GDCoinsObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGordonObjects1Objects = Hashtable.newFrom({"Gordon": gdjs.Game_32SceneCode.GDGordonObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects1Objects = Hashtable.newFrom({"Platform_Ground": gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDStarObjects1Objects = Hashtable.newFrom({"Star": gdjs.Game_32SceneCode.GDStarObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLuckyBlockObjects1Objects = Hashtable.newFrom({"LuckyBlock": gdjs.Game_32SceneCode.GDLuckyBlockObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMushroomObjects1Objects = Hashtable.newFrom({"Mushroom": gdjs.Game_32SceneCode.GDMushroomObjects1});
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(5);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 2);
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 3);
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDPlayerObjects1, gdjs.Game_32SceneCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() == 4);
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Game_32SceneCode.GDLuckyBlockObjects1 */
gdjs.Game_32SceneCode.GDMushroomObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMushroomObjects1Objects, (( gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDLuckyBlockObjects1[0].getPointX("")), (( gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDLuckyBlockObjects1[0].getPointY("")) - 64, "");
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.Game_32SceneCode.GDLuckyBlockObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("Roll", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getPointY("")) > (( gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDLuckyBlockObjects1[0].getPointY("")));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDLuckyBlockObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLuckyBlockObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDLuckyBlockObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber(gdjs.randomInRange(1, 5));
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList0(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


};gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.Game_32SceneCode.GDLuckyBlockObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDLuckyBlockObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDLuckyBlockObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDLuckyBlockObjects1[k] = gdjs.Game_32SceneCode.GDLuckyBlockObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMushroomObjects1Objects = Hashtable.newFrom({"Mushroom": gdjs.Game_32SceneCode.GDMushroomObjects1});
gdjs.Game_32SceneCode.eventsList3 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDMushroomObjects1, gdjs.Game_32SceneCode.GDMushroomObjects2);

gdjs.copyArray(gdjs.Game_32SceneCode.GDPlayerObjects1, gdjs.Game_32SceneCode.GDPlayerObjects2);


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getPointY("")) + (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getHeight()) < (( gdjs.Game_32SceneCode.GDMushroomObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDMushroomObjects2[0].getPointY("")) + 30);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMushroomObjects2 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMushroomObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMushroomObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setPosition(77,437);
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Coin_PitchTimer") > 1;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.randomFloatInRange(0.8, 1));
}
{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "Coin_PitchTimer");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.Game_32SceneCode.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/CoinPickUp.wav", false, 80, runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Coin_PitchTimer");
}
{runtimeScene.getScene().getVariables().getFromIndex(2).add(gdjs.randomWithStep(0.050, 0.1, 0.025));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gordon"), gdjs.Game_32SceneCode.GDGordonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGordonObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatform_95959595GroundObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGordonObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGordonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGordonObjects1[i].setY(400);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Game_32SceneCode.GDMushroomObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMushroomObjects1[i].resetTimer("patrol");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMushroomObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMushroomObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateDownKey();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Star"), gdjs.Game_32SceneCode.GDStarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDStarObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14833996);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 2", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LuckyBlock"), gdjs.Game_32SceneCode.GDLuckyBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLuckyBlockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].rotate(0, runtimeScene);
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Game_32SceneCode.GDMushroomObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMushroomObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMushroomObjects1[i].getTimerElapsedTimeInSecondsOrNaN("patrol") > 2 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMushroomObjects1[k] = gdjs.Game_32SceneCode.GDMushroomObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMushroomObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMushroomObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMushroomObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMushroomObjects1[i].getVariables().getFromIndex(0)).mul(-1);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMushroomObjects1[i].resetTimer("patrol");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Game_32SceneCode.GDMushroomObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMushroomObjects1[i].addForce(60 * gdjs.Game_32SceneCode.GDMushroomObjects1[i].getVariables().getFromIndex(0).getAsNumber(), 0, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Game_32SceneCode.GDMushroomObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMushroomObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17613468);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getY() > 800 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setPosition(77,437);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HudText"), gdjs.Game_32SceneCode.GDHudTextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDHudTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDHudTextObjects1[i].getBehavior("Text").setText("");
}
}
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDCoinsObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoinsObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoinsObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length = 0;
gdjs.Game_32SceneCode.GDLuckyBlockObjects2.length = 0;
gdjs.Game_32SceneCode.GDLuckyBlockObjects3.length = 0;
gdjs.Game_32SceneCode.GDStarObjects1.length = 0;
gdjs.Game_32SceneCode.GDStarObjects2.length = 0;
gdjs.Game_32SceneCode.GDStarObjects3.length = 0;
gdjs.Game_32SceneCode.GDHudTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDHudTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDHudTextObjects3.length = 0;
gdjs.Game_32SceneCode.GDGroundSolidObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundSolidObjects2.length = 0;
gdjs.Game_32SceneCode.GDGroundSolidObjects3.length = 0;
gdjs.Game_32SceneCode.GDGordonObjects1.length = 0;
gdjs.Game_32SceneCode.GDGordonObjects2.length = 0;
gdjs.Game_32SceneCode.GDGordonObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects3.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects1.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects2.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDBridgeObjects1.length = 0;
gdjs.Game_32SceneCode.GDBridgeObjects2.length = 0;
gdjs.Game_32SceneCode.GDBridgeObjects3.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects1.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects2.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595leftObjects1.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595leftObjects2.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595leftObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects3.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595rightObjects1.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595rightObjects2.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595rightObjects3.length = 0;
gdjs.Game_32SceneCode.GDMushroomsObjects1.length = 0;
gdjs.Game_32SceneCode.GDMushroomsObjects2.length = 0;
gdjs.Game_32SceneCode.GDMushroomsObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959511Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959511Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959511Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959512Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959512Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959512Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959513Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959513Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959513Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959515Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959515Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959515Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959514Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959514Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959514Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959516Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959516Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959516Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959519Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959519Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959519Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959517Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959517Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959517Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959518Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959518Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959518Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959520Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959520Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959520Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959521Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959521Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959521Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959522Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959522Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959522Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959523Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959523Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959523Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959524Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959524Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959524Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959526Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959526Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959526Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959527Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959527Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959527Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959525Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959525Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959525Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959528Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959528Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959528Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959529Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959529Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959529Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959531Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959531Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959531Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959535Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959535Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959535Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959532Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959532Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959532Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959536Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959536Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959536Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959537Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959537Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959537Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects1.length = 0;
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects2.length = 0;
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95958Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95958Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95958Objects3.length = 0;
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects3.length = 0;
gdjs.Game_32SceneCode.GDBatObjects1.length = 0;
gdjs.Game_32SceneCode.GDBatObjects2.length = 0;
gdjs.Game_32SceneCode.GDBatObjects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95959Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95959Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95959Objects3.length = 0;
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects1.length = 0;
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects2.length = 0;
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects3.length = 0;
gdjs.Game_32SceneCode.GDDark_9595GuardObjects1.length = 0;
gdjs.Game_32SceneCode.GDDark_9595GuardObjects2.length = 0;
gdjs.Game_32SceneCode.GDDark_9595GuardObjects3.length = 0;
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects3.length = 0;
gdjs.Game_32SceneCode.GDFrogObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrogObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrogObjects3.length = 0;
gdjs.Game_32SceneCode.GDMushroomObjects1.length = 0;
gdjs.Game_32SceneCode.GDMushroomObjects2.length = 0;
gdjs.Game_32SceneCode.GDMushroomObjects3.length = 0;
gdjs.Game_32SceneCode.GDNecromancerObjects1.length = 0;
gdjs.Game_32SceneCode.GDNecromancerObjects2.length = 0;
gdjs.Game_32SceneCode.GDNecromancerObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects3.length = 0;

gdjs.Game_32SceneCode.eventsList4(runtimeScene);
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDCoinsObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoinsObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoinsObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDLuckyBlockObjects1.length = 0;
gdjs.Game_32SceneCode.GDLuckyBlockObjects2.length = 0;
gdjs.Game_32SceneCode.GDLuckyBlockObjects3.length = 0;
gdjs.Game_32SceneCode.GDStarObjects1.length = 0;
gdjs.Game_32SceneCode.GDStarObjects2.length = 0;
gdjs.Game_32SceneCode.GDStarObjects3.length = 0;
gdjs.Game_32SceneCode.GDHudTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDHudTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDHudTextObjects3.length = 0;
gdjs.Game_32SceneCode.GDGroundSolidObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundSolidObjects2.length = 0;
gdjs.Game_32SceneCode.GDGroundSolidObjects3.length = 0;
gdjs.Game_32SceneCode.GDGordonObjects1.length = 0;
gdjs.Game_32SceneCode.GDGordonObjects2.length = 0;
gdjs.Game_32SceneCode.GDGordonObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595foregroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouseObjects3.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects1.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects2.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595HandleObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595tall_9595backgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDHouse_9595small_9595backgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDMerged_9595Full_9595BackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDBridgeObjects1.length = 0;
gdjs.Game_32SceneCode.GDBridgeObjects2.length = 0;
gdjs.Game_32SceneCode.GDBridgeObjects3.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects1.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects2.length = 0;
gdjs.Game_32SceneCode.GDBridge_9595SupportObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595EntranceObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595BackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595leftObjects1.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595leftObjects2.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595leftObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Background_9595HoleObjects3.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595foregroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDGrass_9595backgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595BackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595Background_9595ShadowObjects3.length = 0;
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDBush_9595foregroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595rightObjects1.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595rightObjects2.length = 0;
gdjs.Game_32SceneCode.GDLamp_9595rightObjects3.length = 0;
gdjs.Game_32SceneCode.GDMushroomsObjects1.length = 0;
gdjs.Game_32SceneCode.GDMushroomsObjects2.length = 0;
gdjs.Game_32SceneCode.GDMushroomsObjects3.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.Game_32SceneCode.GDCave_9595Under_9595TileObjects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959511Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959511Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959511Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959512Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959512Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959512Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959513Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959513Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959513Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959515Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959515Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959515Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959514Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959514Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959514Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959516Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959516Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959516Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959519Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959519Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959519Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959517Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959517Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959517Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959518Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959518Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959518Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959520Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959520Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959520Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959521Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959521Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959521Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959522Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959522Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959522Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959523Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959523Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959523Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959524Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959524Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959524Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959526Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959526Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959526Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959527Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959527Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959527Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959525Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959525Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959525Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959528Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959528Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959528Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959529Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959529Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959529Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959531Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959531Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959531Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959535Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959535Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959535Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959532Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959532Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959532Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959536Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959536Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959536Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_959537Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_959537Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_959537Objects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95957Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95957Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95957Objects3.length = 0;
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects1.length = 0;
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects2.length = 0;
gdjs.Game_32SceneCode.GDBoss_9595GolemObjects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95958Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95958Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95958Objects3.length = 0;
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.Game_32SceneCode.GDForest_9595Goblin_9595HogObjects3.length = 0;
gdjs.Game_32SceneCode.GDBatObjects1.length = 0;
gdjs.Game_32SceneCode.GDBatObjects2.length = 0;
gdjs.Game_32SceneCode.GDBatObjects3.length = 0;
gdjs.Game_32SceneCode.GDTile_95959Objects1.length = 0;
gdjs.Game_32SceneCode.GDTile_95959Objects2.length = 0;
gdjs.Game_32SceneCode.GDTile_95959Objects3.length = 0;
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects1.length = 0;
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects2.length = 0;
gdjs.Game_32SceneCode.GDForest_9595GoblinObjects3.length = 0;
gdjs.Game_32SceneCode.GDDark_9595GuardObjects1.length = 0;
gdjs.Game_32SceneCode.GDDark_9595GuardObjects2.length = 0;
gdjs.Game_32SceneCode.GDDark_9595GuardObjects3.length = 0;
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrog_9595TongueObjects3.length = 0;
gdjs.Game_32SceneCode.GDFrogObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrogObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrogObjects3.length = 0;
gdjs.Game_32SceneCode.GDMushroomObjects1.length = 0;
gdjs.Game_32SceneCode.GDMushroomObjects2.length = 0;
gdjs.Game_32SceneCode.GDMushroomObjects3.length = 0;
gdjs.Game_32SceneCode.GDNecromancerObjects1.length = 0;
gdjs.Game_32SceneCode.GDNecromancerObjects2.length = 0;
gdjs.Game_32SceneCode.GDNecromancerObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlant_9595MutantObjects3.length = 0;
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkull_9595SlimeObjects3.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
