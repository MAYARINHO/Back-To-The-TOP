
gdjs.evtsExt__UntitledExtension__MyObject = gdjs.evtsExt__UntitledExtension__MyObject || {};

/**
 * Object generated from 
 */
gdjs.evtsExt__UntitledExtension__MyObject.MyObject = class MyObject extends gdjs.CustomRuntimeObject2D {
  constructor(parentInstanceContainer, objectData, instanceData) {
    super(parentInstanceContainer, objectData, instanceData);
    this._parentInstanceContainer = parentInstanceContainer;

    this._objectData = {};
    
    

    // It calls the onCreated super implementation at the end.
    this.onCreated();
  }

  // Hot-reload:
  updateFromObjectData(oldObjectData, newObjectData) {
    super.updateFromObjectData(oldObjectData, newObjectData);

    this.onHotReloading(this._parentInstanceContainer);
    return true;
  }

  // Properties:
  

  

  
}

// Methods:

gdjs.evtsExt__UntitledExtension__MyObject.MyObject.prototype.doStepPreEvents = function() {
  this._instanceContainer.getOnceTriggers().startNewFrame();
};


gdjs.registerObject("UntitledExtension::MyObject", gdjs.evtsExt__UntitledExtension__MyObject.MyObject);
