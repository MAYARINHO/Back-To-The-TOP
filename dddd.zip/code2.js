gdjs.Level_322Code = {};
gdjs.Level_322Code.localVariables = [];
gdjs.Level_322Code.idToCallbackMap = new Map();
gdjs.Level_322Code.GDPlayerObjects1= [];
gdjs.Level_322Code.GDPlayerObjects2= [];
gdjs.Level_322Code.GDPlayerObjects3= [];
gdjs.Level_322Code.GDPlatform_9595GroundObjects1= [];
gdjs.Level_322Code.GDPlatform_9595GroundObjects2= [];
gdjs.Level_322Code.GDPlatform_9595GroundObjects3= [];
gdjs.Level_322Code.GDCoinsObjects1= [];
gdjs.Level_322Code.GDCoinsObjects2= [];
gdjs.Level_322Code.GDCoinsObjects3= [];
gdjs.Level_322Code.GDBackgroundObjects1= [];
gdjs.Level_322Code.GDBackgroundObjects2= [];
gdjs.Level_322Code.GDBackgroundObjects3= [];
gdjs.Level_322Code.GDLuckyBlockObjects1= [];
gdjs.Level_322Code.GDLuckyBlockObjects2= [];
gdjs.Level_322Code.GDLuckyBlockObjects3= [];
gdjs.Level_322Code.GDStarObjects1= [];
gdjs.Level_322Code.GDStarObjects2= [];
gdjs.Level_322Code.GDStarObjects3= [];
gdjs.Level_322Code.GDHudTextObjects1= [];
gdjs.Level_322Code.GDHudTextObjects2= [];
gdjs.Level_322Code.GDHudTextObjects3= [];
gdjs.Level_322Code.GDGroundSolidObjects1= [];
gdjs.Level_322Code.GDGroundSolidObjects2= [];
gdjs.Level_322Code.GDGroundSolidObjects3= [];
gdjs.Level_322Code.GDGordonObjects1= [];
gdjs.Level_322Code.GDGordonObjects2= [];
gdjs.Level_322Code.GDGordonObjects3= [];
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects1= [];
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects2= [];
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects3= [];
gdjs.Level_322Code.GDHouseObjects1= [];
gdjs.Level_322Code.GDHouseObjects2= [];
gdjs.Level_322Code.GDHouseObjects3= [];
gdjs.Level_322Code.GDBridge_9595HandleObjects1= [];
gdjs.Level_322Code.GDBridge_9595HandleObjects2= [];
gdjs.Level_322Code.GDBridge_9595HandleObjects3= [];
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects1= [];
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects2= [];
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects3= [];
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects1= [];
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects2= [];
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects3= [];
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects1= [];
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects2= [];
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects3= [];
gdjs.Level_322Code.GDBridgeObjects1= [];
gdjs.Level_322Code.GDBridgeObjects2= [];
gdjs.Level_322Code.GDBridgeObjects3= [];
gdjs.Level_322Code.GDBridge_9595SupportObjects1= [];
gdjs.Level_322Code.GDBridge_9595SupportObjects2= [];
gdjs.Level_322Code.GDBridge_9595SupportObjects3= [];
gdjs.Level_322Code.GDCave_9595EntranceObjects1= [];
gdjs.Level_322Code.GDCave_9595EntranceObjects2= [];
gdjs.Level_322Code.GDCave_9595EntranceObjects3= [];
gdjs.Level_322Code.GDCave_9595BackgroundObjects1= [];
gdjs.Level_322Code.GDCave_9595BackgroundObjects2= [];
gdjs.Level_322Code.GDCave_9595BackgroundObjects3= [];
gdjs.Level_322Code.GDLamp_9595leftObjects1= [];
gdjs.Level_322Code.GDLamp_9595leftObjects2= [];
gdjs.Level_322Code.GDLamp_9595leftObjects3= [];
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects1= [];
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects2= [];
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects3= [];
gdjs.Level_322Code.GDGrass_9595foregroundObjects1= [];
gdjs.Level_322Code.GDGrass_9595foregroundObjects2= [];
gdjs.Level_322Code.GDGrass_9595foregroundObjects3= [];
gdjs.Level_322Code.GDGrass_9595backgroundObjects1= [];
gdjs.Level_322Code.GDGrass_9595backgroundObjects2= [];
gdjs.Level_322Code.GDGrass_9595backgroundObjects3= [];
gdjs.Level_322Code.GDBush_9595BackgroundObjects1= [];
gdjs.Level_322Code.GDBush_9595BackgroundObjects2= [];
gdjs.Level_322Code.GDBush_9595BackgroundObjects3= [];
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects1= [];
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects2= [];
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects3= [];
gdjs.Level_322Code.GDBush_9595foregroundObjects1= [];
gdjs.Level_322Code.GDBush_9595foregroundObjects2= [];
gdjs.Level_322Code.GDBush_9595foregroundObjects3= [];
gdjs.Level_322Code.GDLamp_9595rightObjects1= [];
gdjs.Level_322Code.GDLamp_9595rightObjects2= [];
gdjs.Level_322Code.GDLamp_9595rightObjects3= [];
gdjs.Level_322Code.GDMushroomsObjects1= [];
gdjs.Level_322Code.GDMushroomsObjects2= [];
gdjs.Level_322Code.GDMushroomsObjects3= [];
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects1= [];
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects2= [];
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects3= [];
gdjs.Level_322Code.GDTile_959511Objects1= [];
gdjs.Level_322Code.GDTile_959511Objects2= [];
gdjs.Level_322Code.GDTile_959511Objects3= [];
gdjs.Level_322Code.GDTile_95951Objects1= [];
gdjs.Level_322Code.GDTile_95951Objects2= [];
gdjs.Level_322Code.GDTile_95951Objects3= [];
gdjs.Level_322Code.GDTile_959512Objects1= [];
gdjs.Level_322Code.GDTile_959512Objects2= [];
gdjs.Level_322Code.GDTile_959512Objects3= [];
gdjs.Level_322Code.GDTile_959513Objects1= [];
gdjs.Level_322Code.GDTile_959513Objects2= [];
gdjs.Level_322Code.GDTile_959513Objects3= [];
gdjs.Level_322Code.GDTile_959515Objects1= [];
gdjs.Level_322Code.GDTile_959515Objects2= [];
gdjs.Level_322Code.GDTile_959515Objects3= [];
gdjs.Level_322Code.GDTile_959514Objects1= [];
gdjs.Level_322Code.GDTile_959514Objects2= [];
gdjs.Level_322Code.GDTile_959514Objects3= [];
gdjs.Level_322Code.GDTile_959516Objects1= [];
gdjs.Level_322Code.GDTile_959516Objects2= [];
gdjs.Level_322Code.GDTile_959516Objects3= [];
gdjs.Level_322Code.GDTile_959519Objects1= [];
gdjs.Level_322Code.GDTile_959519Objects2= [];
gdjs.Level_322Code.GDTile_959519Objects3= [];
gdjs.Level_322Code.GDTile_959517Objects1= [];
gdjs.Level_322Code.GDTile_959517Objects2= [];
gdjs.Level_322Code.GDTile_959517Objects3= [];
gdjs.Level_322Code.GDTile_959518Objects1= [];
gdjs.Level_322Code.GDTile_959518Objects2= [];
gdjs.Level_322Code.GDTile_959518Objects3= [];
gdjs.Level_322Code.GDTile_95952Objects1= [];
gdjs.Level_322Code.GDTile_95952Objects2= [];
gdjs.Level_322Code.GDTile_95952Objects3= [];
gdjs.Level_322Code.GDTile_959520Objects1= [];
gdjs.Level_322Code.GDTile_959520Objects2= [];
gdjs.Level_322Code.GDTile_959520Objects3= [];
gdjs.Level_322Code.GDTile_959521Objects1= [];
gdjs.Level_322Code.GDTile_959521Objects2= [];
gdjs.Level_322Code.GDTile_959521Objects3= [];
gdjs.Level_322Code.GDTile_959522Objects1= [];
gdjs.Level_322Code.GDTile_959522Objects2= [];
gdjs.Level_322Code.GDTile_959522Objects3= [];
gdjs.Level_322Code.GDTile_959523Objects1= [];
gdjs.Level_322Code.GDTile_959523Objects2= [];
gdjs.Level_322Code.GDTile_959523Objects3= [];
gdjs.Level_322Code.GDTile_959524Objects1= [];
gdjs.Level_322Code.GDTile_959524Objects2= [];
gdjs.Level_322Code.GDTile_959524Objects3= [];
gdjs.Level_322Code.GDTile_959526Objects1= [];
gdjs.Level_322Code.GDTile_959526Objects2= [];
gdjs.Level_322Code.GDTile_959526Objects3= [];
gdjs.Level_322Code.GDTile_959527Objects1= [];
gdjs.Level_322Code.GDTile_959527Objects2= [];
gdjs.Level_322Code.GDTile_959527Objects3= [];
gdjs.Level_322Code.GDTile_959525Objects1= [];
gdjs.Level_322Code.GDTile_959525Objects2= [];
gdjs.Level_322Code.GDTile_959525Objects3= [];
gdjs.Level_322Code.GDTile_959528Objects1= [];
gdjs.Level_322Code.GDTile_959528Objects2= [];
gdjs.Level_322Code.GDTile_959528Objects3= [];
gdjs.Level_322Code.GDTile_959529Objects1= [];
gdjs.Level_322Code.GDTile_959529Objects2= [];
gdjs.Level_322Code.GDTile_959529Objects3= [];
gdjs.Level_322Code.GDTile_959531Objects1= [];
gdjs.Level_322Code.GDTile_959531Objects2= [];
gdjs.Level_322Code.GDTile_959531Objects3= [];
gdjs.Level_322Code.GDTile_959535Objects1= [];
gdjs.Level_322Code.GDTile_959535Objects2= [];
gdjs.Level_322Code.GDTile_959535Objects3= [];
gdjs.Level_322Code.GDTile_959532Objects1= [];
gdjs.Level_322Code.GDTile_959532Objects2= [];
gdjs.Level_322Code.GDTile_959532Objects3= [];
gdjs.Level_322Code.GDTile_959536Objects1= [];
gdjs.Level_322Code.GDTile_959536Objects2= [];
gdjs.Level_322Code.GDTile_959536Objects3= [];
gdjs.Level_322Code.GDTile_959537Objects1= [];
gdjs.Level_322Code.GDTile_959537Objects2= [];
gdjs.Level_322Code.GDTile_959537Objects3= [];
gdjs.Level_322Code.GDTile_95957Objects1= [];
gdjs.Level_322Code.GDTile_95957Objects2= [];
gdjs.Level_322Code.GDTile_95957Objects3= [];
gdjs.Level_322Code.GDBoss_9595GolemObjects1= [];
gdjs.Level_322Code.GDBoss_9595GolemObjects2= [];
gdjs.Level_322Code.GDBoss_9595GolemObjects3= [];
gdjs.Level_322Code.GDTile_95958Objects1= [];
gdjs.Level_322Code.GDTile_95958Objects2= [];
gdjs.Level_322Code.GDTile_95958Objects3= [];
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects1= [];
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects2= [];
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects3= [];
gdjs.Level_322Code.GDBatObjects1= [];
gdjs.Level_322Code.GDBatObjects2= [];
gdjs.Level_322Code.GDBatObjects3= [];
gdjs.Level_322Code.GDTile_95959Objects1= [];
gdjs.Level_322Code.GDTile_95959Objects2= [];
gdjs.Level_322Code.GDTile_95959Objects3= [];
gdjs.Level_322Code.GDForest_9595GoblinObjects1= [];
gdjs.Level_322Code.GDForest_9595GoblinObjects2= [];
gdjs.Level_322Code.GDForest_9595GoblinObjects3= [];
gdjs.Level_322Code.GDDark_9595GuardObjects1= [];
gdjs.Level_322Code.GDDark_9595GuardObjects2= [];
gdjs.Level_322Code.GDDark_9595GuardObjects3= [];
gdjs.Level_322Code.GDFrog_9595TongueObjects1= [];
gdjs.Level_322Code.GDFrog_9595TongueObjects2= [];
gdjs.Level_322Code.GDFrog_9595TongueObjects3= [];
gdjs.Level_322Code.GDFrogObjects1= [];
gdjs.Level_322Code.GDFrogObjects2= [];
gdjs.Level_322Code.GDFrogObjects3= [];
gdjs.Level_322Code.GDMushroomObjects1= [];
gdjs.Level_322Code.GDMushroomObjects2= [];
gdjs.Level_322Code.GDMushroomObjects3= [];
gdjs.Level_322Code.GDNecromancerObjects1= [];
gdjs.Level_322Code.GDNecromancerObjects2= [];
gdjs.Level_322Code.GDNecromancerObjects3= [];
gdjs.Level_322Code.GDPlant_9595MutantObjects1= [];
gdjs.Level_322Code.GDPlant_9595MutantObjects2= [];
gdjs.Level_322Code.GDPlant_9595MutantObjects3= [];
gdjs.Level_322Code.GDSkull_9595SlimeObjects1= [];
gdjs.Level_322Code.GDSkull_9595SlimeObjects2= [];
gdjs.Level_322Code.GDSkull_9595SlimeObjects3= [];


gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_322Code.GDPlayerObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDStarObjects1Objects = Hashtable.newFrom({"Star": gdjs.Level_322Code.GDStarObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_322Code.GDPlayerObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.Level_322Code.GDCoinsObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_322Code.GDPlayerObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDLuckyBlockObjects1Objects = Hashtable.newFrom({"LuckyBlock": gdjs.Level_322Code.GDLuckyBlockObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDBatObjects1Objects = Hashtable.newFrom({"Bat": gdjs.Level_322Code.GDBatObjects1});
gdjs.Level_322Code.eventsList0 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Level_322Code.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(5);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Level_322Code.localVariables[0].getFromIndex(0).getAsNumber() == 2);
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Level_322Code.localVariables[0].getFromIndex(0).getAsNumber() == 3);
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(gdjs.Level_322Code.GDPlayerObjects1, gdjs.Level_322Code.GDPlayerObjects2);

{for(var i = 0, len = gdjs.Level_322Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_322Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Level_322Code.localVariables[0].getFromIndex(0).getAsNumber() == 4);
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Level_322Code.GDLuckyBlockObjects1 */
gdjs.Level_322Code.GDBatObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDBatObjects1Objects, (( gdjs.Level_322Code.GDLuckyBlockObjects1.length === 0 ) ? 0 :gdjs.Level_322Code.GDLuckyBlockObjects1[0].getPointX("")), (( gdjs.Level_322Code.GDLuckyBlockObjects1.length === 0 ) ? 0 :gdjs.Level_322Code.GDLuckyBlockObjects1[0].getPointY("")) - 64, "");
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Level_322Code.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.Level_322Code.GDLuckyBlockObjects1 */
/* Reuse gdjs.Level_322Code.GDPlayerObjects1 */

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("Roll", variable);
}
gdjs.Level_322Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Level_322Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level_322Code.GDPlayerObjects1[0].getPointY("")) > (( gdjs.Level_322Code.GDLuckyBlockObjects1.length === 0 ) ? 0 :gdjs.Level_322Code.GDLuckyBlockObjects1[0].getPointY("")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDLuckyBlockObjects1 */
{for(var i = 0, len = gdjs.Level_322Code.GDLuckyBlockObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDLuckyBlockObjects1[i].returnVariable(gdjs.Level_322Code.GDLuckyBlockObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{gdjs.Level_322Code.localVariables[0].getFromIndex(0).setNumber(gdjs.randomInRange(1, 5));
}

{ //Subevents
gdjs.Level_322Code.eventsList0(runtimeScene);} //End of subevents
}
gdjs.Level_322Code.localVariables.pop();

}


};gdjs.Level_322Code.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.Level_322Code.GDPlayerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_322Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Level_322Code.GDPlayerObjects1[k] = gdjs.Level_322Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_322Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Level_322Code.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.Level_322Code.GDLuckyBlockObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_322Code.GDLuckyBlockObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDLuckyBlockObjects1[i].getVariableNumber(gdjs.Level_322Code.GDLuckyBlockObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level_322Code.GDLuckyBlockObjects1[k] = gdjs.Level_322Code.GDLuckyBlockObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDLuckyBlockObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_322Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_322Code.GDPlayerObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDMushroomObjects1Objects = Hashtable.newFrom({"Mushroom": gdjs.Level_322Code.GDMushroomObjects1});
gdjs.Level_322Code.eventsList4 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(gdjs.Level_322Code.GDMushroomObjects1, gdjs.Level_322Code.GDMushroomObjects2);

gdjs.copyArray(gdjs.Level_322Code.GDPlayerObjects1, gdjs.Level_322Code.GDPlayerObjects2);


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Level_322Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_322Code.GDPlayerObjects2[0].getPointY("")) + (( gdjs.Level_322Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_322Code.GDPlayerObjects2[0].getHeight()) < (( gdjs.Level_322Code.GDMushroomObjects2.length === 0 ) ? 0 :gdjs.Level_322Code.GDMushroomObjects2[0].getPointY("")) + 30);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDMushroomObjects2 */
/* Reuse gdjs.Level_322Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_322Code.GDMushroomObjects2.length ;i < len;++i) {
    gdjs.Level_322Code.GDMushroomObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_322Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Level_322Code.GDPlayerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.Level_322Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPlayerObjects1[i].setPosition(77,437);
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_322Code.GDPlayerObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDFrogObjects1Objects = Hashtable.newFrom({"Frog": gdjs.Level_322Code.GDFrogObjects1});
gdjs.Level_322Code.eventsList5 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(gdjs.Level_322Code.GDFrogObjects1, gdjs.Level_322Code.GDFrogObjects2);

gdjs.copyArray(gdjs.Level_322Code.GDPlayerObjects1, gdjs.Level_322Code.GDPlayerObjects2);


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Level_322Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_322Code.GDPlayerObjects2[0].getPointY("")) + (( gdjs.Level_322Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level_322Code.GDPlayerObjects2[0].getHeight()) < (( gdjs.Level_322Code.GDFrogObjects2.length === 0 ) ? 0 :gdjs.Level_322Code.GDFrogObjects2[0].getPointY("")) + 30);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDFrogObjects2 */
/* Reuse gdjs.Level_322Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level_322Code.GDFrogObjects2.length ;i < len;++i) {
    gdjs.Level_322Code.GDFrogObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level_322Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Level_322Code.GDPlayerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.Level_322Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPlayerObjects1[i].setPosition(77,437);
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level_322Code.GDPlayerObjects1});
gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDBatObjects1Objects = Hashtable.newFrom({"Bat": gdjs.Level_322Code.GDBatObjects1});
gdjs.Level_322Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Frog"), gdjs.Level_322Code.GDFrogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Level_322Code.GDMushroomObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}
{for(var i = 0, len = gdjs.Level_322Code.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDMushroomObjects1[i].resetTimer("patrol");
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDMushroomObjects1[i].returnVariable(gdjs.Level_322Code.GDMushroomObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDFrogObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDFrogObjects1[i].resetTimer("patrol");
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDFrogObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDFrogObjects1[i].returnVariable(gdjs.Level_322Code.GDFrogObjects1[i].getVariables().getFromIndex(0)).setNumber(-1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_322Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Star"), gdjs.Level_322Code.GDStarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects, gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDStarObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16916908);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 3", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.Level_322Code.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_322Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects, gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.Level_322Code.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LuckyBlock"), gdjs.Level_322Code.GDLuckyBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_322Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects, gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDLuckyBlockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_322Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Level_322Code.GDMushroomObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_322Code.GDMushroomObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDMushroomObjects1[i].getTimerElapsedTimeInSecondsOrNaN("patrol") > 2 ) {
        isConditionTrue_0 = true;
        gdjs.Level_322Code.GDMushroomObjects1[k] = gdjs.Level_322Code.GDMushroomObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDMushroomObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDMushroomObjects1 */
{for(var i = 0, len = gdjs.Level_322Code.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDMushroomObjects1[i].returnVariable(gdjs.Level_322Code.GDMushroomObjects1[i].getVariables().getFromIndex(0)).mul(-1);
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDMushroomObjects1[i].resetTimer("patrol");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Frog"), gdjs.Level_322Code.GDFrogObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_322Code.GDFrogObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDFrogObjects1[i].getTimerElapsedTimeInSecondsOrNaN("patrol") > 2 ) {
        isConditionTrue_0 = true;
        gdjs.Level_322Code.GDFrogObjects1[k] = gdjs.Level_322Code.GDFrogObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDFrogObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDFrogObjects1 */
{for(var i = 0, len = gdjs.Level_322Code.GDFrogObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDFrogObjects1[i].returnVariable(gdjs.Level_322Code.GDFrogObjects1[i].getVariables().getFromIndex(0)).mul(-1);
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDFrogObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDFrogObjects1[i].resetTimer("patrol");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bat"), gdjs.Level_322Code.GDBatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Frog"), gdjs.Level_322Code.GDFrogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Level_322Code.GDMushroomObjects1);
{for(var i = 0, len = gdjs.Level_322Code.GDMushroomObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDMushroomObjects1[i].addForce(80 * gdjs.Level_322Code.GDMushroomObjects1[i].getVariables().getFromIndex(0).getAsNumber(), 0, 0);
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDFrogObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDFrogObjects1[i].addForce(100 * gdjs.Level_322Code.GDFrogObjects1[i].getVariables().getFromIndex(0).getAsNumber(), 0, 0);
}
}
{for(var i = 0, len = gdjs.Level_322Code.GDBatObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDBatObjects1[i].addForce(60 * Math.cos(gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) * 2), -40, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mushroom"), gdjs.Level_322Code.GDMushroomObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_322Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects, gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDMushroomObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17077508);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_322Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Frog"), gdjs.Level_322Code.GDFrogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_322Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects, gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDFrogObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19996252);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level_322Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bat"), gdjs.Level_322Code.GDBatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_322Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDPlayerObjects1Objects, gdjs.Level_322Code.mapOfGDgdjs_9546Level_9595322Code_9546GDBatObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16920852);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDPlayerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.Level_322Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPlayerObjects1[i].setPosition(77,437);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level_322Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_322Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDPlayerObjects1[i].getY() > 800 ) {
        isConditionTrue_0 = true;
        gdjs.Level_322Code.GDPlayerObjects1[k] = gdjs.Level_322Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level_322Code.GDPlayerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.Level_322Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPlayerObjects1[i].setPosition(77,437);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HudText"), gdjs.Level_322Code.GDHudTextObjects1);
{for(var i = 0, len = gdjs.Level_322Code.GDHudTextObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDHudTextObjects1[i].getBehavior("Text").setText("");
}
}
}

}


};

gdjs.Level_322Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_322Code.GDPlayerObjects1.length = 0;
gdjs.Level_322Code.GDPlayerObjects2.length = 0;
gdjs.Level_322Code.GDPlayerObjects3.length = 0;
gdjs.Level_322Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Level_322Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Level_322Code.GDPlatform_9595GroundObjects3.length = 0;
gdjs.Level_322Code.GDCoinsObjects1.length = 0;
gdjs.Level_322Code.GDCoinsObjects2.length = 0;
gdjs.Level_322Code.GDCoinsObjects3.length = 0;
gdjs.Level_322Code.GDBackgroundObjects1.length = 0;
gdjs.Level_322Code.GDBackgroundObjects2.length = 0;
gdjs.Level_322Code.GDBackgroundObjects3.length = 0;
gdjs.Level_322Code.GDLuckyBlockObjects1.length = 0;
gdjs.Level_322Code.GDLuckyBlockObjects2.length = 0;
gdjs.Level_322Code.GDLuckyBlockObjects3.length = 0;
gdjs.Level_322Code.GDStarObjects1.length = 0;
gdjs.Level_322Code.GDStarObjects2.length = 0;
gdjs.Level_322Code.GDStarObjects3.length = 0;
gdjs.Level_322Code.GDHudTextObjects1.length = 0;
gdjs.Level_322Code.GDHudTextObjects2.length = 0;
gdjs.Level_322Code.GDHudTextObjects3.length = 0;
gdjs.Level_322Code.GDGroundSolidObjects1.length = 0;
gdjs.Level_322Code.GDGroundSolidObjects2.length = 0;
gdjs.Level_322Code.GDGroundSolidObjects3.length = 0;
gdjs.Level_322Code.GDGordonObjects1.length = 0;
gdjs.Level_322Code.GDGordonObjects2.length = 0;
gdjs.Level_322Code.GDGordonObjects3.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects3.length = 0;
gdjs.Level_322Code.GDHouseObjects1.length = 0;
gdjs.Level_322Code.GDHouseObjects2.length = 0;
gdjs.Level_322Code.GDHouseObjects3.length = 0;
gdjs.Level_322Code.GDBridge_9595HandleObjects1.length = 0;
gdjs.Level_322Code.GDBridge_9595HandleObjects2.length = 0;
gdjs.Level_322Code.GDBridge_9595HandleObjects3.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects3.length = 0;
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects3.length = 0;
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects3.length = 0;
gdjs.Level_322Code.GDBridgeObjects1.length = 0;
gdjs.Level_322Code.GDBridgeObjects2.length = 0;
gdjs.Level_322Code.GDBridgeObjects3.length = 0;
gdjs.Level_322Code.GDBridge_9595SupportObjects1.length = 0;
gdjs.Level_322Code.GDBridge_9595SupportObjects2.length = 0;
gdjs.Level_322Code.GDBridge_9595SupportObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595EntranceObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595EntranceObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595EntranceObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595BackgroundObjects3.length = 0;
gdjs.Level_322Code.GDLamp_9595leftObjects1.length = 0;
gdjs.Level_322Code.GDLamp_9595leftObjects2.length = 0;
gdjs.Level_322Code.GDLamp_9595leftObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects3.length = 0;
gdjs.Level_322Code.GDGrass_9595foregroundObjects1.length = 0;
gdjs.Level_322Code.GDGrass_9595foregroundObjects2.length = 0;
gdjs.Level_322Code.GDGrass_9595foregroundObjects3.length = 0;
gdjs.Level_322Code.GDGrass_9595backgroundObjects1.length = 0;
gdjs.Level_322Code.GDGrass_9595backgroundObjects2.length = 0;
gdjs.Level_322Code.GDGrass_9595backgroundObjects3.length = 0;
gdjs.Level_322Code.GDBush_9595BackgroundObjects1.length = 0;
gdjs.Level_322Code.GDBush_9595BackgroundObjects2.length = 0;
gdjs.Level_322Code.GDBush_9595BackgroundObjects3.length = 0;
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects3.length = 0;
gdjs.Level_322Code.GDBush_9595foregroundObjects1.length = 0;
gdjs.Level_322Code.GDBush_9595foregroundObjects2.length = 0;
gdjs.Level_322Code.GDBush_9595foregroundObjects3.length = 0;
gdjs.Level_322Code.GDLamp_9595rightObjects1.length = 0;
gdjs.Level_322Code.GDLamp_9595rightObjects2.length = 0;
gdjs.Level_322Code.GDLamp_9595rightObjects3.length = 0;
gdjs.Level_322Code.GDMushroomsObjects1.length = 0;
gdjs.Level_322Code.GDMushroomsObjects2.length = 0;
gdjs.Level_322Code.GDMushroomsObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects3.length = 0;
gdjs.Level_322Code.GDTile_959511Objects1.length = 0;
gdjs.Level_322Code.GDTile_959511Objects2.length = 0;
gdjs.Level_322Code.GDTile_959511Objects3.length = 0;
gdjs.Level_322Code.GDTile_95951Objects1.length = 0;
gdjs.Level_322Code.GDTile_95951Objects2.length = 0;
gdjs.Level_322Code.GDTile_95951Objects3.length = 0;
gdjs.Level_322Code.GDTile_959512Objects1.length = 0;
gdjs.Level_322Code.GDTile_959512Objects2.length = 0;
gdjs.Level_322Code.GDTile_959512Objects3.length = 0;
gdjs.Level_322Code.GDTile_959513Objects1.length = 0;
gdjs.Level_322Code.GDTile_959513Objects2.length = 0;
gdjs.Level_322Code.GDTile_959513Objects3.length = 0;
gdjs.Level_322Code.GDTile_959515Objects1.length = 0;
gdjs.Level_322Code.GDTile_959515Objects2.length = 0;
gdjs.Level_322Code.GDTile_959515Objects3.length = 0;
gdjs.Level_322Code.GDTile_959514Objects1.length = 0;
gdjs.Level_322Code.GDTile_959514Objects2.length = 0;
gdjs.Level_322Code.GDTile_959514Objects3.length = 0;
gdjs.Level_322Code.GDTile_959516Objects1.length = 0;
gdjs.Level_322Code.GDTile_959516Objects2.length = 0;
gdjs.Level_322Code.GDTile_959516Objects3.length = 0;
gdjs.Level_322Code.GDTile_959519Objects1.length = 0;
gdjs.Level_322Code.GDTile_959519Objects2.length = 0;
gdjs.Level_322Code.GDTile_959519Objects3.length = 0;
gdjs.Level_322Code.GDTile_959517Objects1.length = 0;
gdjs.Level_322Code.GDTile_959517Objects2.length = 0;
gdjs.Level_322Code.GDTile_959517Objects3.length = 0;
gdjs.Level_322Code.GDTile_959518Objects1.length = 0;
gdjs.Level_322Code.GDTile_959518Objects2.length = 0;
gdjs.Level_322Code.GDTile_959518Objects3.length = 0;
gdjs.Level_322Code.GDTile_95952Objects1.length = 0;
gdjs.Level_322Code.GDTile_95952Objects2.length = 0;
gdjs.Level_322Code.GDTile_95952Objects3.length = 0;
gdjs.Level_322Code.GDTile_959520Objects1.length = 0;
gdjs.Level_322Code.GDTile_959520Objects2.length = 0;
gdjs.Level_322Code.GDTile_959520Objects3.length = 0;
gdjs.Level_322Code.GDTile_959521Objects1.length = 0;
gdjs.Level_322Code.GDTile_959521Objects2.length = 0;
gdjs.Level_322Code.GDTile_959521Objects3.length = 0;
gdjs.Level_322Code.GDTile_959522Objects1.length = 0;
gdjs.Level_322Code.GDTile_959522Objects2.length = 0;
gdjs.Level_322Code.GDTile_959522Objects3.length = 0;
gdjs.Level_322Code.GDTile_959523Objects1.length = 0;
gdjs.Level_322Code.GDTile_959523Objects2.length = 0;
gdjs.Level_322Code.GDTile_959523Objects3.length = 0;
gdjs.Level_322Code.GDTile_959524Objects1.length = 0;
gdjs.Level_322Code.GDTile_959524Objects2.length = 0;
gdjs.Level_322Code.GDTile_959524Objects3.length = 0;
gdjs.Level_322Code.GDTile_959526Objects1.length = 0;
gdjs.Level_322Code.GDTile_959526Objects2.length = 0;
gdjs.Level_322Code.GDTile_959526Objects3.length = 0;
gdjs.Level_322Code.GDTile_959527Objects1.length = 0;
gdjs.Level_322Code.GDTile_959527Objects2.length = 0;
gdjs.Level_322Code.GDTile_959527Objects3.length = 0;
gdjs.Level_322Code.GDTile_959525Objects1.length = 0;
gdjs.Level_322Code.GDTile_959525Objects2.length = 0;
gdjs.Level_322Code.GDTile_959525Objects3.length = 0;
gdjs.Level_322Code.GDTile_959528Objects1.length = 0;
gdjs.Level_322Code.GDTile_959528Objects2.length = 0;
gdjs.Level_322Code.GDTile_959528Objects3.length = 0;
gdjs.Level_322Code.GDTile_959529Objects1.length = 0;
gdjs.Level_322Code.GDTile_959529Objects2.length = 0;
gdjs.Level_322Code.GDTile_959529Objects3.length = 0;
gdjs.Level_322Code.GDTile_959531Objects1.length = 0;
gdjs.Level_322Code.GDTile_959531Objects2.length = 0;
gdjs.Level_322Code.GDTile_959531Objects3.length = 0;
gdjs.Level_322Code.GDTile_959535Objects1.length = 0;
gdjs.Level_322Code.GDTile_959535Objects2.length = 0;
gdjs.Level_322Code.GDTile_959535Objects3.length = 0;
gdjs.Level_322Code.GDTile_959532Objects1.length = 0;
gdjs.Level_322Code.GDTile_959532Objects2.length = 0;
gdjs.Level_322Code.GDTile_959532Objects3.length = 0;
gdjs.Level_322Code.GDTile_959536Objects1.length = 0;
gdjs.Level_322Code.GDTile_959536Objects2.length = 0;
gdjs.Level_322Code.GDTile_959536Objects3.length = 0;
gdjs.Level_322Code.GDTile_959537Objects1.length = 0;
gdjs.Level_322Code.GDTile_959537Objects2.length = 0;
gdjs.Level_322Code.GDTile_959537Objects3.length = 0;
gdjs.Level_322Code.GDTile_95957Objects1.length = 0;
gdjs.Level_322Code.GDTile_95957Objects2.length = 0;
gdjs.Level_322Code.GDTile_95957Objects3.length = 0;
gdjs.Level_322Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.Level_322Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.Level_322Code.GDBoss_9595GolemObjects3.length = 0;
gdjs.Level_322Code.GDTile_95958Objects1.length = 0;
gdjs.Level_322Code.GDTile_95958Objects2.length = 0;
gdjs.Level_322Code.GDTile_95958Objects3.length = 0;
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects3.length = 0;
gdjs.Level_322Code.GDBatObjects1.length = 0;
gdjs.Level_322Code.GDBatObjects2.length = 0;
gdjs.Level_322Code.GDBatObjects3.length = 0;
gdjs.Level_322Code.GDTile_95959Objects1.length = 0;
gdjs.Level_322Code.GDTile_95959Objects2.length = 0;
gdjs.Level_322Code.GDTile_95959Objects3.length = 0;
gdjs.Level_322Code.GDForest_9595GoblinObjects1.length = 0;
gdjs.Level_322Code.GDForest_9595GoblinObjects2.length = 0;
gdjs.Level_322Code.GDForest_9595GoblinObjects3.length = 0;
gdjs.Level_322Code.GDDark_9595GuardObjects1.length = 0;
gdjs.Level_322Code.GDDark_9595GuardObjects2.length = 0;
gdjs.Level_322Code.GDDark_9595GuardObjects3.length = 0;
gdjs.Level_322Code.GDFrog_9595TongueObjects1.length = 0;
gdjs.Level_322Code.GDFrog_9595TongueObjects2.length = 0;
gdjs.Level_322Code.GDFrog_9595TongueObjects3.length = 0;
gdjs.Level_322Code.GDFrogObjects1.length = 0;
gdjs.Level_322Code.GDFrogObjects2.length = 0;
gdjs.Level_322Code.GDFrogObjects3.length = 0;
gdjs.Level_322Code.GDMushroomObjects1.length = 0;
gdjs.Level_322Code.GDMushroomObjects2.length = 0;
gdjs.Level_322Code.GDMushroomObjects3.length = 0;
gdjs.Level_322Code.GDNecromancerObjects1.length = 0;
gdjs.Level_322Code.GDNecromancerObjects2.length = 0;
gdjs.Level_322Code.GDNecromancerObjects3.length = 0;
gdjs.Level_322Code.GDPlant_9595MutantObjects1.length = 0;
gdjs.Level_322Code.GDPlant_9595MutantObjects2.length = 0;
gdjs.Level_322Code.GDPlant_9595MutantObjects3.length = 0;
gdjs.Level_322Code.GDSkull_9595SlimeObjects1.length = 0;
gdjs.Level_322Code.GDSkull_9595SlimeObjects2.length = 0;
gdjs.Level_322Code.GDSkull_9595SlimeObjects3.length = 0;

gdjs.Level_322Code.eventsList6(runtimeScene);
gdjs.Level_322Code.GDPlayerObjects1.length = 0;
gdjs.Level_322Code.GDPlayerObjects2.length = 0;
gdjs.Level_322Code.GDPlayerObjects3.length = 0;
gdjs.Level_322Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Level_322Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Level_322Code.GDPlatform_9595GroundObjects3.length = 0;
gdjs.Level_322Code.GDCoinsObjects1.length = 0;
gdjs.Level_322Code.GDCoinsObjects2.length = 0;
gdjs.Level_322Code.GDCoinsObjects3.length = 0;
gdjs.Level_322Code.GDBackgroundObjects1.length = 0;
gdjs.Level_322Code.GDBackgroundObjects2.length = 0;
gdjs.Level_322Code.GDBackgroundObjects3.length = 0;
gdjs.Level_322Code.GDLuckyBlockObjects1.length = 0;
gdjs.Level_322Code.GDLuckyBlockObjects2.length = 0;
gdjs.Level_322Code.GDLuckyBlockObjects3.length = 0;
gdjs.Level_322Code.GDStarObjects1.length = 0;
gdjs.Level_322Code.GDStarObjects2.length = 0;
gdjs.Level_322Code.GDStarObjects3.length = 0;
gdjs.Level_322Code.GDHudTextObjects1.length = 0;
gdjs.Level_322Code.GDHudTextObjects2.length = 0;
gdjs.Level_322Code.GDHudTextObjects3.length = 0;
gdjs.Level_322Code.GDGroundSolidObjects1.length = 0;
gdjs.Level_322Code.GDGroundSolidObjects2.length = 0;
gdjs.Level_322Code.GDGroundSolidObjects3.length = 0;
gdjs.Level_322Code.GDGordonObjects1.length = 0;
gdjs.Level_322Code.GDGordonObjects2.length = 0;
gdjs.Level_322Code.GDGordonObjects3.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595foregroundObjects3.length = 0;
gdjs.Level_322Code.GDHouseObjects1.length = 0;
gdjs.Level_322Code.GDHouseObjects2.length = 0;
gdjs.Level_322Code.GDHouseObjects3.length = 0;
gdjs.Level_322Code.GDBridge_9595HandleObjects1.length = 0;
gdjs.Level_322Code.GDBridge_9595HandleObjects2.length = 0;
gdjs.Level_322Code.GDBridge_9595HandleObjects3.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.Level_322Code.GDHouse_9595tall_9595backgroundObjects3.length = 0;
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.Level_322Code.GDHouse_9595small_9595backgroundObjects3.length = 0;
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.Level_322Code.GDMerged_9595Full_9595BackgroundObjects3.length = 0;
gdjs.Level_322Code.GDBridgeObjects1.length = 0;
gdjs.Level_322Code.GDBridgeObjects2.length = 0;
gdjs.Level_322Code.GDBridgeObjects3.length = 0;
gdjs.Level_322Code.GDBridge_9595SupportObjects1.length = 0;
gdjs.Level_322Code.GDBridge_9595SupportObjects2.length = 0;
gdjs.Level_322Code.GDBridge_9595SupportObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595EntranceObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595EntranceObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595EntranceObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595BackgroundObjects3.length = 0;
gdjs.Level_322Code.GDLamp_9595leftObjects1.length = 0;
gdjs.Level_322Code.GDLamp_9595leftObjects2.length = 0;
gdjs.Level_322Code.GDLamp_9595leftObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595Background_9595HoleObjects3.length = 0;
gdjs.Level_322Code.GDGrass_9595foregroundObjects1.length = 0;
gdjs.Level_322Code.GDGrass_9595foregroundObjects2.length = 0;
gdjs.Level_322Code.GDGrass_9595foregroundObjects3.length = 0;
gdjs.Level_322Code.GDGrass_9595backgroundObjects1.length = 0;
gdjs.Level_322Code.GDGrass_9595backgroundObjects2.length = 0;
gdjs.Level_322Code.GDGrass_9595backgroundObjects3.length = 0;
gdjs.Level_322Code.GDBush_9595BackgroundObjects1.length = 0;
gdjs.Level_322Code.GDBush_9595BackgroundObjects2.length = 0;
gdjs.Level_322Code.GDBush_9595BackgroundObjects3.length = 0;
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.Level_322Code.GDBush_9595Background_9595ShadowObjects3.length = 0;
gdjs.Level_322Code.GDBush_9595foregroundObjects1.length = 0;
gdjs.Level_322Code.GDBush_9595foregroundObjects2.length = 0;
gdjs.Level_322Code.GDBush_9595foregroundObjects3.length = 0;
gdjs.Level_322Code.GDLamp_9595rightObjects1.length = 0;
gdjs.Level_322Code.GDLamp_9595rightObjects2.length = 0;
gdjs.Level_322Code.GDLamp_9595rightObjects3.length = 0;
gdjs.Level_322Code.GDMushroomsObjects1.length = 0;
gdjs.Level_322Code.GDMushroomsObjects2.length = 0;
gdjs.Level_322Code.GDMushroomsObjects3.length = 0;
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.Level_322Code.GDCave_9595Under_9595TileObjects3.length = 0;
gdjs.Level_322Code.GDTile_959511Objects1.length = 0;
gdjs.Level_322Code.GDTile_959511Objects2.length = 0;
gdjs.Level_322Code.GDTile_959511Objects3.length = 0;
gdjs.Level_322Code.GDTile_95951Objects1.length = 0;
gdjs.Level_322Code.GDTile_95951Objects2.length = 0;
gdjs.Level_322Code.GDTile_95951Objects3.length = 0;
gdjs.Level_322Code.GDTile_959512Objects1.length = 0;
gdjs.Level_322Code.GDTile_959512Objects2.length = 0;
gdjs.Level_322Code.GDTile_959512Objects3.length = 0;
gdjs.Level_322Code.GDTile_959513Objects1.length = 0;
gdjs.Level_322Code.GDTile_959513Objects2.length = 0;
gdjs.Level_322Code.GDTile_959513Objects3.length = 0;
gdjs.Level_322Code.GDTile_959515Objects1.length = 0;
gdjs.Level_322Code.GDTile_959515Objects2.length = 0;
gdjs.Level_322Code.GDTile_959515Objects3.length = 0;
gdjs.Level_322Code.GDTile_959514Objects1.length = 0;
gdjs.Level_322Code.GDTile_959514Objects2.length = 0;
gdjs.Level_322Code.GDTile_959514Objects3.length = 0;
gdjs.Level_322Code.GDTile_959516Objects1.length = 0;
gdjs.Level_322Code.GDTile_959516Objects2.length = 0;
gdjs.Level_322Code.GDTile_959516Objects3.length = 0;
gdjs.Level_322Code.GDTile_959519Objects1.length = 0;
gdjs.Level_322Code.GDTile_959519Objects2.length = 0;
gdjs.Level_322Code.GDTile_959519Objects3.length = 0;
gdjs.Level_322Code.GDTile_959517Objects1.length = 0;
gdjs.Level_322Code.GDTile_959517Objects2.length = 0;
gdjs.Level_322Code.GDTile_959517Objects3.length = 0;
gdjs.Level_322Code.GDTile_959518Objects1.length = 0;
gdjs.Level_322Code.GDTile_959518Objects2.length = 0;
gdjs.Level_322Code.GDTile_959518Objects3.length = 0;
gdjs.Level_322Code.GDTile_95952Objects1.length = 0;
gdjs.Level_322Code.GDTile_95952Objects2.length = 0;
gdjs.Level_322Code.GDTile_95952Objects3.length = 0;
gdjs.Level_322Code.GDTile_959520Objects1.length = 0;
gdjs.Level_322Code.GDTile_959520Objects2.length = 0;
gdjs.Level_322Code.GDTile_959520Objects3.length = 0;
gdjs.Level_322Code.GDTile_959521Objects1.length = 0;
gdjs.Level_322Code.GDTile_959521Objects2.length = 0;
gdjs.Level_322Code.GDTile_959521Objects3.length = 0;
gdjs.Level_322Code.GDTile_959522Objects1.length = 0;
gdjs.Level_322Code.GDTile_959522Objects2.length = 0;
gdjs.Level_322Code.GDTile_959522Objects3.length = 0;
gdjs.Level_322Code.GDTile_959523Objects1.length = 0;
gdjs.Level_322Code.GDTile_959523Objects2.length = 0;
gdjs.Level_322Code.GDTile_959523Objects3.length = 0;
gdjs.Level_322Code.GDTile_959524Objects1.length = 0;
gdjs.Level_322Code.GDTile_959524Objects2.length = 0;
gdjs.Level_322Code.GDTile_959524Objects3.length = 0;
gdjs.Level_322Code.GDTile_959526Objects1.length = 0;
gdjs.Level_322Code.GDTile_959526Objects2.length = 0;
gdjs.Level_322Code.GDTile_959526Objects3.length = 0;
gdjs.Level_322Code.GDTile_959527Objects1.length = 0;
gdjs.Level_322Code.GDTile_959527Objects2.length = 0;
gdjs.Level_322Code.GDTile_959527Objects3.length = 0;
gdjs.Level_322Code.GDTile_959525Objects1.length = 0;
gdjs.Level_322Code.GDTile_959525Objects2.length = 0;
gdjs.Level_322Code.GDTile_959525Objects3.length = 0;
gdjs.Level_322Code.GDTile_959528Objects1.length = 0;
gdjs.Level_322Code.GDTile_959528Objects2.length = 0;
gdjs.Level_322Code.GDTile_959528Objects3.length = 0;
gdjs.Level_322Code.GDTile_959529Objects1.length = 0;
gdjs.Level_322Code.GDTile_959529Objects2.length = 0;
gdjs.Level_322Code.GDTile_959529Objects3.length = 0;
gdjs.Level_322Code.GDTile_959531Objects1.length = 0;
gdjs.Level_322Code.GDTile_959531Objects2.length = 0;
gdjs.Level_322Code.GDTile_959531Objects3.length = 0;
gdjs.Level_322Code.GDTile_959535Objects1.length = 0;
gdjs.Level_322Code.GDTile_959535Objects2.length = 0;
gdjs.Level_322Code.GDTile_959535Objects3.length = 0;
gdjs.Level_322Code.GDTile_959532Objects1.length = 0;
gdjs.Level_322Code.GDTile_959532Objects2.length = 0;
gdjs.Level_322Code.GDTile_959532Objects3.length = 0;
gdjs.Level_322Code.GDTile_959536Objects1.length = 0;
gdjs.Level_322Code.GDTile_959536Objects2.length = 0;
gdjs.Level_322Code.GDTile_959536Objects3.length = 0;
gdjs.Level_322Code.GDTile_959537Objects1.length = 0;
gdjs.Level_322Code.GDTile_959537Objects2.length = 0;
gdjs.Level_322Code.GDTile_959537Objects3.length = 0;
gdjs.Level_322Code.GDTile_95957Objects1.length = 0;
gdjs.Level_322Code.GDTile_95957Objects2.length = 0;
gdjs.Level_322Code.GDTile_95957Objects3.length = 0;
gdjs.Level_322Code.GDBoss_9595GolemObjects1.length = 0;
gdjs.Level_322Code.GDBoss_9595GolemObjects2.length = 0;
gdjs.Level_322Code.GDBoss_9595GolemObjects3.length = 0;
gdjs.Level_322Code.GDTile_95958Objects1.length = 0;
gdjs.Level_322Code.GDTile_95958Objects2.length = 0;
gdjs.Level_322Code.GDTile_95958Objects3.length = 0;
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.Level_322Code.GDForest_9595Goblin_9595HogObjects3.length = 0;
gdjs.Level_322Code.GDBatObjects1.length = 0;
gdjs.Level_322Code.GDBatObjects2.length = 0;
gdjs.Level_322Code.GDBatObjects3.length = 0;
gdjs.Level_322Code.GDTile_95959Objects1.length = 0;
gdjs.Level_322Code.GDTile_95959Objects2.length = 0;
gdjs.Level_322Code.GDTile_95959Objects3.length = 0;
gdjs.Level_322Code.GDForest_9595GoblinObjects1.length = 0;
gdjs.Level_322Code.GDForest_9595GoblinObjects2.length = 0;
gdjs.Level_322Code.GDForest_9595GoblinObjects3.length = 0;
gdjs.Level_322Code.GDDark_9595GuardObjects1.length = 0;
gdjs.Level_322Code.GDDark_9595GuardObjects2.length = 0;
gdjs.Level_322Code.GDDark_9595GuardObjects3.length = 0;
gdjs.Level_322Code.GDFrog_9595TongueObjects1.length = 0;
gdjs.Level_322Code.GDFrog_9595TongueObjects2.length = 0;
gdjs.Level_322Code.GDFrog_9595TongueObjects3.length = 0;
gdjs.Level_322Code.GDFrogObjects1.length = 0;
gdjs.Level_322Code.GDFrogObjects2.length = 0;
gdjs.Level_322Code.GDFrogObjects3.length = 0;
gdjs.Level_322Code.GDMushroomObjects1.length = 0;
gdjs.Level_322Code.GDMushroomObjects2.length = 0;
gdjs.Level_322Code.GDMushroomObjects3.length = 0;
gdjs.Level_322Code.GDNecromancerObjects1.length = 0;
gdjs.Level_322Code.GDNecromancerObjects2.length = 0;
gdjs.Level_322Code.GDNecromancerObjects3.length = 0;
gdjs.Level_322Code.GDPlant_9595MutantObjects1.length = 0;
gdjs.Level_322Code.GDPlant_9595MutantObjects2.length = 0;
gdjs.Level_322Code.GDPlant_9595MutantObjects3.length = 0;
gdjs.Level_322Code.GDSkull_9595SlimeObjects1.length = 0;
gdjs.Level_322Code.GDSkull_9595SlimeObjects2.length = 0;
gdjs.Level_322Code.GDSkull_9595SlimeObjects3.length = 0;


return;

}

gdjs['Level_322Code'] = gdjs.Level_322Code;
