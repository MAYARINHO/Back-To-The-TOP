
gdjs.evtsExt__Player__PlayerBehavior = gdjs.evtsExt__Player__PlayerBehavior || {};

/**
 * Behavior generated from 
 */
gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior = class PlayerBehavior extends gdjs.RuntimeBehavior {
  constructor(instanceContainer, behaviorData, owner) {
    super(instanceContainer, behaviorData, owner);
    this._runtimeScene = instanceContainer;

    this._onceTriggers = new gdjs.OnceTriggers();
    this._behaviorData = {};
    this._sharedData = gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.getSharedData(
      instanceContainer,
      behaviorData.name
    );
    
    this._behaviorData.PlatformerMultitouchMapper = behaviorData.PlatformerMultitouchMapper !== undefined ? behaviorData.PlatformerMultitouchMapper : "";
    this._behaviorData.PlatformerObject = behaviorData.PlatformerObject !== undefined ? behaviorData.PlatformerObject : "";
    this._behaviorData.SmoothCamera = behaviorData.SmoothCamera !== undefined ? behaviorData.SmoothCamera : "";
  }

  // Hot-reload:
  applyBehaviorOverriding(behaviorOverriding) {
    
    if (behaviorOverriding.PlatformerMultitouchMapper !== undefined)
      this._behaviorData.PlatformerMultitouchMapper = behaviorOverriding.PlatformerMultitouchMapper;
    if (behaviorOverriding.PlatformerObject !== undefined)
      this._behaviorData.PlatformerObject = behaviorOverriding.PlatformerObject;
    if (behaviorOverriding.SmoothCamera !== undefined)
      this._behaviorData.SmoothCamera = behaviorOverriding.SmoothCamera;

    return true;
  }

  // Network sync:
  getNetworkSyncData(syncOptions) {
    return {
      ...super.getNetworkSyncData(syncOptions),
      props: {
        
    PlatformerMultitouchMapper: this._behaviorData.PlatformerMultitouchMapper,
    PlatformerObject: this._behaviorData.PlatformerObject,
    SmoothCamera: this._behaviorData.SmoothCamera,
      }
    };
  }
  updateFromNetworkSyncData(networkSyncData, options) {
    super.updateFromNetworkSyncData(networkSyncData, options);
    
    if (networkSyncData.props.PlatformerMultitouchMapper !== undefined)
      this._behaviorData.PlatformerMultitouchMapper = networkSyncData.props.PlatformerMultitouchMapper;
    if (networkSyncData.props.PlatformerObject !== undefined)
      this._behaviorData.PlatformerObject = networkSyncData.props.PlatformerObject;
    if (networkSyncData.props.SmoothCamera !== undefined)
      this._behaviorData.SmoothCamera = networkSyncData.props.SmoothCamera;
  }

  // Properties:
  
  _getPlatformerMultitouchMapper() {
    return this._behaviorData.PlatformerMultitouchMapper !== undefined ? this._behaviorData.PlatformerMultitouchMapper : "";
  }
  _setPlatformerMultitouchMapper(newValue) {
    this._behaviorData.PlatformerMultitouchMapper = newValue;
  }
  _getPlatformerObject() {
    return this._behaviorData.PlatformerObject !== undefined ? this._behaviorData.PlatformerObject : "";
  }
  _setPlatformerObject(newValue) {
    this._behaviorData.PlatformerObject = newValue;
  }
  _getSmoothCamera() {
    return this._behaviorData.SmoothCamera !== undefined ? this._behaviorData.SmoothCamera : "";
  }
  _setSmoothCamera(newValue) {
    this._behaviorData.SmoothCamera = newValue;
  }
}

/**
 * Shared data generated from 
 */
gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.SharedData = class PlayerBehaviorSharedData {
  constructor(sharedData) {
    
  }
  
  // Shared properties:
  
}

gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.getSharedData = function(instanceContainer, behaviorName) {
  if (!instanceContainer._Player_PlayerBehaviorSharedData) {
    const initialData = instanceContainer.getInitialSharedDataForBehavior(
      behaviorName
    );
    instanceContainer._Player_PlayerBehaviorSharedData = new gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.SharedData(
      initialData
    );
  }
  return instanceContainer._Player_PlayerBehaviorSharedData;
}

// Methods:
gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.prototype.doStepPreEventsContext = {};
gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.prototype.doStepPreEventsContext.idToCallbackMap = new Map();


gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.prototype.doStepPreEventsContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

};

gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.prototype.doStepPreEvents = function(parentEventsFunctionContext) {
this._onceTriggers.startNewFrame();
var that = this;
var runtimeScene = this._runtimeScene;
let scopeInstanceContainer = null;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
, "PlatformerMultitouchMapper": this._getPlatformerMultitouchMapper()
, "PlatformerObject": this._getPlatformerObject()
, "SmoothCamera": this._getSmoothCamera()
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("Player"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("Player"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};


gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior.prototype.doStepPreEventsContext.eventsList0(runtimeScene, eventsFunctionContext);


return;
}


gdjs.registerBehavior("Player::PlayerBehavior", gdjs.evtsExt__Player__PlayerBehavior.PlayerBehavior);
