gdjs.IntroCode = {};
gdjs.IntroCode.localVariables = [];
gdjs.IntroCode.idToCallbackMap = new Map();
gdjs.IntroCode.GDMyObjectObjects1= [];
gdjs.IntroCode.GDMyObjectObjects2= [];
gdjs.IntroCode.GDPlayerObjects1= [];
gdjs.IntroCode.GDPlayerObjects2= [];
gdjs.IntroCode.GDPlatform_9595GroundObjects1= [];
gdjs.IntroCode.GDPlatform_9595GroundObjects2= [];
gdjs.IntroCode.GDCoinsObjects1= [];
gdjs.IntroCode.GDCoinsObjects2= [];
gdjs.IntroCode.GDBackgroundObjects1= [];
gdjs.IntroCode.GDBackgroundObjects2= [];
gdjs.IntroCode.GDStarObjects1= [];
gdjs.IntroCode.GDStarObjects2= [];
gdjs.IntroCode.GDStoryTextObjects1= [];
gdjs.IntroCode.GDStoryTextObjects2= [];
gdjs.IntroCode.GDNewVideoObjects1= [];
gdjs.IntroCode.GDNewVideoObjects2= [];
gdjs.IntroCode.GDNewVideo2Objects1= [];
gdjs.IntroCode.GDNewVideo2Objects2= [];
gdjs.IntroCode.GDGordonObjects1= [];
gdjs.IntroCode.GDGordonObjects2= [];
gdjs.IntroCode.GDHouse_9595tall_9595foregroundObjects1= [];
gdjs.IntroCode.GDHouse_9595tall_9595foregroundObjects2= [];
gdjs.IntroCode.GDHouseObjects1= [];
gdjs.IntroCode.GDHouseObjects2= [];
gdjs.IntroCode.GDBridge_9595HandleObjects1= [];
gdjs.IntroCode.GDBridge_9595HandleObjects2= [];
gdjs.IntroCode.GDHouse_9595tall_9595backgroundObjects1= [];
gdjs.IntroCode.GDHouse_9595tall_9595backgroundObjects2= [];
gdjs.IntroCode.GDHouse_9595small_9595backgroundObjects1= [];
gdjs.IntroCode.GDHouse_9595small_9595backgroundObjects2= [];
gdjs.IntroCode.GDMerged_9595Full_9595BackgroundObjects1= [];
gdjs.IntroCode.GDMerged_9595Full_9595BackgroundObjects2= [];
gdjs.IntroCode.GDBridgeObjects1= [];
gdjs.IntroCode.GDBridgeObjects2= [];
gdjs.IntroCode.GDBridge_9595SupportObjects1= [];
gdjs.IntroCode.GDBridge_9595SupportObjects2= [];
gdjs.IntroCode.GDCave_9595EntranceObjects1= [];
gdjs.IntroCode.GDCave_9595EntranceObjects2= [];
gdjs.IntroCode.GDCave_9595BackgroundObjects1= [];
gdjs.IntroCode.GDCave_9595BackgroundObjects2= [];
gdjs.IntroCode.GDLamp_9595leftObjects1= [];
gdjs.IntroCode.GDLamp_9595leftObjects2= [];
gdjs.IntroCode.GDCave_9595Background_9595HoleObjects1= [];
gdjs.IntroCode.GDCave_9595Background_9595HoleObjects2= [];
gdjs.IntroCode.GDGrass_9595foregroundObjects1= [];
gdjs.IntroCode.GDGrass_9595foregroundObjects2= [];
gdjs.IntroCode.GDGrass_9595backgroundObjects1= [];
gdjs.IntroCode.GDGrass_9595backgroundObjects2= [];
gdjs.IntroCode.GDBush_9595BackgroundObjects1= [];
gdjs.IntroCode.GDBush_9595BackgroundObjects2= [];
gdjs.IntroCode.GDBush_9595Background_9595ShadowObjects1= [];
gdjs.IntroCode.GDBush_9595Background_9595ShadowObjects2= [];
gdjs.IntroCode.GDBush_9595foregroundObjects1= [];
gdjs.IntroCode.GDBush_9595foregroundObjects2= [];
gdjs.IntroCode.GDLamp_9595rightObjects1= [];
gdjs.IntroCode.GDLamp_9595rightObjects2= [];
gdjs.IntroCode.GDMushroomsObjects1= [];
gdjs.IntroCode.GDMushroomsObjects2= [];
gdjs.IntroCode.GDCave_9595Under_9595TileObjects1= [];
gdjs.IntroCode.GDCave_9595Under_9595TileObjects2= [];
gdjs.IntroCode.GDTile_959511Objects1= [];
gdjs.IntroCode.GDTile_959511Objects2= [];
gdjs.IntroCode.GDTile_95951Objects1= [];
gdjs.IntroCode.GDTile_95951Objects2= [];
gdjs.IntroCode.GDTile_959512Objects1= [];
gdjs.IntroCode.GDTile_959512Objects2= [];
gdjs.IntroCode.GDTile_959513Objects1= [];
gdjs.IntroCode.GDTile_959513Objects2= [];
gdjs.IntroCode.GDTile_959515Objects1= [];
gdjs.IntroCode.GDTile_959515Objects2= [];
gdjs.IntroCode.GDTile_959514Objects1= [];
gdjs.IntroCode.GDTile_959514Objects2= [];
gdjs.IntroCode.GDTile_959516Objects1= [];
gdjs.IntroCode.GDTile_959516Objects2= [];
gdjs.IntroCode.GDTile_959519Objects1= [];
gdjs.IntroCode.GDTile_959519Objects2= [];
gdjs.IntroCode.GDTile_959517Objects1= [];
gdjs.IntroCode.GDTile_959517Objects2= [];
gdjs.IntroCode.GDTile_959518Objects1= [];
gdjs.IntroCode.GDTile_959518Objects2= [];
gdjs.IntroCode.GDTile_95952Objects1= [];
gdjs.IntroCode.GDTile_95952Objects2= [];
gdjs.IntroCode.GDTile_959520Objects1= [];
gdjs.IntroCode.GDTile_959520Objects2= [];
gdjs.IntroCode.GDTile_959521Objects1= [];
gdjs.IntroCode.GDTile_959521Objects2= [];
gdjs.IntroCode.GDTile_959522Objects1= [];
gdjs.IntroCode.GDTile_959522Objects2= [];
gdjs.IntroCode.GDTile_959523Objects1= [];
gdjs.IntroCode.GDTile_959523Objects2= [];
gdjs.IntroCode.GDTile_959524Objects1= [];
gdjs.IntroCode.GDTile_959524Objects2= [];
gdjs.IntroCode.GDTile_959526Objects1= [];
gdjs.IntroCode.GDTile_959526Objects2= [];
gdjs.IntroCode.GDTile_959527Objects1= [];
gdjs.IntroCode.GDTile_959527Objects2= [];
gdjs.IntroCode.GDTile_959525Objects1= [];
gdjs.IntroCode.GDTile_959525Objects2= [];
gdjs.IntroCode.GDTile_959528Objects1= [];
gdjs.IntroCode.GDTile_959528Objects2= [];
gdjs.IntroCode.GDTile_959529Objects1= [];
gdjs.IntroCode.GDTile_959529Objects2= [];
gdjs.IntroCode.GDTile_959531Objects1= [];
gdjs.IntroCode.GDTile_959531Objects2= [];
gdjs.IntroCode.GDTile_959535Objects1= [];
gdjs.IntroCode.GDTile_959535Objects2= [];
gdjs.IntroCode.GDTile_959532Objects1= [];
gdjs.IntroCode.GDTile_959532Objects2= [];
gdjs.IntroCode.GDTile_959536Objects1= [];
gdjs.IntroCode.GDTile_959536Objects2= [];
gdjs.IntroCode.GDTile_959537Objects1= [];
gdjs.IntroCode.GDTile_959537Objects2= [];
gdjs.IntroCode.GDTile_95957Objects1= [];
gdjs.IntroCode.GDTile_95957Objects2= [];
gdjs.IntroCode.GDBoss_9595GolemObjects1= [];
gdjs.IntroCode.GDBoss_9595GolemObjects2= [];
gdjs.IntroCode.GDTile_95958Objects1= [];
gdjs.IntroCode.GDTile_95958Objects2= [];
gdjs.IntroCode.GDForest_9595Goblin_9595HogObjects1= [];
gdjs.IntroCode.GDForest_9595Goblin_9595HogObjects2= [];
gdjs.IntroCode.GDBatObjects1= [];
gdjs.IntroCode.GDBatObjects2= [];
gdjs.IntroCode.GDTile_95959Objects1= [];
gdjs.IntroCode.GDTile_95959Objects2= [];
gdjs.IntroCode.GDForest_9595GoblinObjects1= [];
gdjs.IntroCode.GDForest_9595GoblinObjects2= [];
gdjs.IntroCode.GDDark_9595GuardObjects1= [];
gdjs.IntroCode.GDDark_9595GuardObjects2= [];
gdjs.IntroCode.GDFrog_9595TongueObjects1= [];
gdjs.IntroCode.GDFrog_9595TongueObjects2= [];
gdjs.IntroCode.GDFrogObjects1= [];
gdjs.IntroCode.GDFrogObjects2= [];
gdjs.IntroCode.GDMushroomObjects1= [];
gdjs.IntroCode.GDMushroomObjects2= [];
gdjs.IntroCode.GDNecromancerObjects1= [];
gdjs.IntroCode.GDNecromancerObjects2= [];
gdjs.IntroCode.GDPlant_9595MutantObjects1= [];
gdjs.IntroCode.GDPlant_9595MutantObjects2= [];
gdjs.IntroCode.GDSkull_9595SlimeObjects1= [];
gdjs.IntroCode.GDSkull_9595SlimeObjects2= [];


gdjs.IntroCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
}

}


};gdjs.IntroCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("StoryText"), gdjs.IntroCode.GDStoryTextObjects1);
{for(var i = 0, len = gdjs.IntroCode.GDStoryTextObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDStoryTextObjects1[i].getBehavior("Text").setText("Gordon climbed the mountain for the star... he slipped!");
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "IntroWait");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "IntroWait") > 1.2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20762156);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.IntroCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("StoryText"), gdjs.IntroCode.GDStoryTextObjects1);
{for(var i = 0, len = gdjs.IntroCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDPlayerObjects1[i].getBehavior("Tween").addObjectPositionTween2("fall", 615, 560, runtimeScene.getGame().getNamedEasingsManager().resolve("easeInQuad", ""), 1.2, false);
}
}
{for(var i = 0, len = gdjs.IntroCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDPlayerObjects1[i].getBehavior("Tween").addObjectAngleTween2("spin", 360, runtimeScene.getGame().getNamedEasingsManager().resolve("linear", ""), 1.2, false);
}
}
{for(var i = 0, len = gdjs.IntroCode.GDStoryTextObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDStoryTextObjects1[i].getBehavior("Text").setText("AAAH! Falling...");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.IntroCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.IntroCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.IntroCode.GDPlayerObjects1[i].getBehavior("Tween").hasFinished("fall") ) {
        isConditionTrue_0 = true;
        gdjs.IntroCode.GDPlayerObjects1[k] = gdjs.IntroCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.IntroCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20010836);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("StoryText"), gdjs.IntroCode.GDStoryTextObjects1);
{for(var i = 0, len = gdjs.IntroCode.GDStoryTextObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDStoryTextObjects1[i].getBehavior("Text").setText("OUCH! That hurt. 3 levels to climb back! TAP or SPACE!");
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "GoTimer");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "GoTimer") > 1.0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.IntroCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.IntroCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.IntroCode.GDMyObjectObjects1.length = 0;
gdjs.IntroCode.GDMyObjectObjects2.length = 0;
gdjs.IntroCode.GDPlayerObjects1.length = 0;
gdjs.IntroCode.GDPlayerObjects2.length = 0;
gdjs.IntroCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.IntroCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.IntroCode.GDCoinsObjects1.length = 0;
gdjs.IntroCode.GDCoinsObjects2.length = 0;
gdjs.IntroCode.GDBackgroundObjects1.length = 0;
gdjs.IntroCode.GDBackgroundObjects2.length = 0;
gdjs.IntroCode.GDStarObjects1.length = 0;
gdjs.IntroCode.GDStarObjects2.length = 0;
gdjs.IntroCode.GDStoryTextObjects1.length = 0;
gdjs.IntroCode.GDStoryTextObjects2.length = 0;
gdjs.IntroCode.GDNewVideoObjects1.length = 0;
gdjs.IntroCode.GDNewVideoObjects2.length = 0;
gdjs.IntroCode.GDNewVideo2Objects1.length = 0;
gdjs.IntroCode.GDNewVideo2Objects2.length = 0;
gdjs.IntroCode.GDGordonObjects1.length = 0;
gdjs.IntroCode.GDGordonObjects2.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.IntroCode.GDHouseObjects1.length = 0;
gdjs.IntroCode.GDHouseObjects2.length = 0;
gdjs.IntroCode.GDBridge_9595HandleObjects1.length = 0;
gdjs.IntroCode.GDBridge_9595HandleObjects2.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.IntroCode.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.IntroCode.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.IntroCode.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.IntroCode.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.IntroCode.GDBridgeObjects1.length = 0;
gdjs.IntroCode.GDBridgeObjects2.length = 0;
gdjs.IntroCode.GDBridge_9595SupportObjects1.length = 0;
gdjs.IntroCode.GDBridge_9595SupportObjects2.length = 0;
gdjs.IntroCode.GDCave_9595EntranceObjects1.length = 0;
gdjs.IntroCode.GDCave_9595EntranceObjects2.length = 0;
gdjs.IntroCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.IntroCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.IntroCode.GDLamp_9595leftObjects1.length = 0;
gdjs.IntroCode.GDLamp_9595leftObjects2.length = 0;
gdjs.IntroCode.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.IntroCode.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.IntroCode.GDGrass_9595foregroundObjects1.length = 0;
gdjs.IntroCode.GDGrass_9595foregroundObjects2.length = 0;
gdjs.IntroCode.GDGrass_9595backgroundObjects1.length = 0;
gdjs.IntroCode.GDGrass_9595backgroundObjects2.length = 0;
gdjs.IntroCode.GDBush_9595BackgroundObjects1.length = 0;
gdjs.IntroCode.GDBush_9595BackgroundObjects2.length = 0;
gdjs.IntroCode.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.IntroCode.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.IntroCode.GDBush_9595foregroundObjects1.length = 0;
gdjs.IntroCode.GDBush_9595foregroundObjects2.length = 0;
gdjs.IntroCode.GDLamp_9595rightObjects1.length = 0;
gdjs.IntroCode.GDLamp_9595rightObjects2.length = 0;
gdjs.IntroCode.GDMushroomsObjects1.length = 0;
gdjs.IntroCode.GDMushroomsObjects2.length = 0;
gdjs.IntroCode.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.IntroCode.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.IntroCode.GDTile_959511Objects1.length = 0;
gdjs.IntroCode.GDTile_959511Objects2.length = 0;
gdjs.IntroCode.GDTile_95951Objects1.length = 0;
gdjs.IntroCode.GDTile_95951Objects2.length = 0;
gdjs.IntroCode.GDTile_959512Objects1.length = 0;
gdjs.IntroCode.GDTile_959512Objects2.length = 0;
gdjs.IntroCode.GDTile_959513Objects1.length = 0;
gdjs.IntroCode.GDTile_959513Objects2.length = 0;
gdjs.IntroCode.GDTile_959515Objects1.length = 0;
gdjs.IntroCode.GDTile_959515Objects2.length = 0;
gdjs.IntroCode.GDTile_959514Objects1.length = 0;
gdjs.IntroCode.GDTile_959514Objects2.length = 0;
gdjs.IntroCode.GDTile_959516Objects1.length = 0;
gdjs.IntroCode.GDTile_959516Objects2.length = 0;
gdjs.IntroCode.GDTile_959519Objects1.length = 0;
gdjs.IntroCode.GDTile_959519Objects2.length = 0;
gdjs.IntroCode.GDTile_959517Objects1.length = 0;
gdjs.IntroCode.GDTile_959517Objects2.length = 0;
gdjs.IntroCode.GDTile_959518Objects1.length = 0;
gdjs.IntroCode.GDTile_959518Objects2.length = 0;
gdjs.IntroCode.GDTile_95952Objects1.length = 0;
gdjs.IntroCode.GDTile_95952Objects2.length = 0;
gdjs.IntroCode.GDTile_959520Objects1.length = 0;
gdjs.IntroCode.GDTile_959520Objects2.length = 0;
gdjs.IntroCode.GDTile_959521Objects1.length = 0;
gdjs.IntroCode.GDTile_959521Objects2.length = 0;
gdjs.IntroCode.GDTile_959522Objects1.length = 0;
gdjs.IntroCode.GDTile_959522Objects2.length = 0;
gdjs.IntroCode.GDTile_959523Objects1.length = 0;
gdjs.IntroCode.GDTile_959523Objects2.length = 0;
gdjs.IntroCode.GDTile_959524Objects1.length = 0;
gdjs.IntroCode.GDTile_959524Objects2.length = 0;
gdjs.IntroCode.GDTile_959526Objects1.length = 0;
gdjs.IntroCode.GDTile_959526Objects2.length = 0;
gdjs.IntroCode.GDTile_959527Objects1.length = 0;
gdjs.IntroCode.GDTile_959527Objects2.length = 0;
gdjs.IntroCode.GDTile_959525Objects1.length = 0;
gdjs.IntroCode.GDTile_959525Objects2.length = 0;
gdjs.IntroCode.GDTile_959528Objects1.length = 0;
gdjs.IntroCode.GDTile_959528Objects2.length = 0;
gdjs.IntroCode.GDTile_959529Objects1.length = 0;
gdjs.IntroCode.GDTile_959529Objects2.length = 0;
gdjs.IntroCode.GDTile_959531Objects1.length = 0;
gdjs.IntroCode.GDTile_959531Objects2.length = 0;
gdjs.IntroCode.GDTile_959535Objects1.length = 0;
gdjs.IntroCode.GDTile_959535Objects2.length = 0;
gdjs.IntroCode.GDTile_959532Objects1.length = 0;
gdjs.IntroCode.GDTile_959532Objects2.length = 0;
gdjs.IntroCode.GDTile_959536Objects1.length = 0;
gdjs.IntroCode.GDTile_959536Objects2.length = 0;
gdjs.IntroCode.GDTile_959537Objects1.length = 0;
gdjs.IntroCode.GDTile_959537Objects2.length = 0;
gdjs.IntroCode.GDTile_95957Objects1.length = 0;
gdjs.IntroCode.GDTile_95957Objects2.length = 0;
gdjs.IntroCode.GDBoss_9595GolemObjects1.length = 0;
gdjs.IntroCode.GDBoss_9595GolemObjects2.length = 0;
gdjs.IntroCode.GDTile_95958Objects1.length = 0;
gdjs.IntroCode.GDTile_95958Objects2.length = 0;
gdjs.IntroCode.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.IntroCode.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.IntroCode.GDBatObjects1.length = 0;
gdjs.IntroCode.GDBatObjects2.length = 0;
gdjs.IntroCode.GDTile_95959Objects1.length = 0;
gdjs.IntroCode.GDTile_95959Objects2.length = 0;
gdjs.IntroCode.GDForest_9595GoblinObjects1.length = 0;
gdjs.IntroCode.GDForest_9595GoblinObjects2.length = 0;
gdjs.IntroCode.GDDark_9595GuardObjects1.length = 0;
gdjs.IntroCode.GDDark_9595GuardObjects2.length = 0;
gdjs.IntroCode.GDFrog_9595TongueObjects1.length = 0;
gdjs.IntroCode.GDFrog_9595TongueObjects2.length = 0;
gdjs.IntroCode.GDFrogObjects1.length = 0;
gdjs.IntroCode.GDFrogObjects2.length = 0;
gdjs.IntroCode.GDMushroomObjects1.length = 0;
gdjs.IntroCode.GDMushroomObjects2.length = 0;
gdjs.IntroCode.GDNecromancerObjects1.length = 0;
gdjs.IntroCode.GDNecromancerObjects2.length = 0;
gdjs.IntroCode.GDPlant_9595MutantObjects1.length = 0;
gdjs.IntroCode.GDPlant_9595MutantObjects2.length = 0;
gdjs.IntroCode.GDSkull_9595SlimeObjects1.length = 0;
gdjs.IntroCode.GDSkull_9595SlimeObjects2.length = 0;

gdjs.IntroCode.eventsList1(runtimeScene);
gdjs.IntroCode.GDMyObjectObjects1.length = 0;
gdjs.IntroCode.GDMyObjectObjects2.length = 0;
gdjs.IntroCode.GDPlayerObjects1.length = 0;
gdjs.IntroCode.GDPlayerObjects2.length = 0;
gdjs.IntroCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.IntroCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.IntroCode.GDCoinsObjects1.length = 0;
gdjs.IntroCode.GDCoinsObjects2.length = 0;
gdjs.IntroCode.GDBackgroundObjects1.length = 0;
gdjs.IntroCode.GDBackgroundObjects2.length = 0;
gdjs.IntroCode.GDStarObjects1.length = 0;
gdjs.IntroCode.GDStarObjects2.length = 0;
gdjs.IntroCode.GDStoryTextObjects1.length = 0;
gdjs.IntroCode.GDStoryTextObjects2.length = 0;
gdjs.IntroCode.GDNewVideoObjects1.length = 0;
gdjs.IntroCode.GDNewVideoObjects2.length = 0;
gdjs.IntroCode.GDNewVideo2Objects1.length = 0;
gdjs.IntroCode.GDNewVideo2Objects2.length = 0;
gdjs.IntroCode.GDGordonObjects1.length = 0;
gdjs.IntroCode.GDGordonObjects2.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595foregroundObjects1.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595foregroundObjects2.length = 0;
gdjs.IntroCode.GDHouseObjects1.length = 0;
gdjs.IntroCode.GDHouseObjects2.length = 0;
gdjs.IntroCode.GDBridge_9595HandleObjects1.length = 0;
gdjs.IntroCode.GDBridge_9595HandleObjects2.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595backgroundObjects1.length = 0;
gdjs.IntroCode.GDHouse_9595tall_9595backgroundObjects2.length = 0;
gdjs.IntroCode.GDHouse_9595small_9595backgroundObjects1.length = 0;
gdjs.IntroCode.GDHouse_9595small_9595backgroundObjects2.length = 0;
gdjs.IntroCode.GDMerged_9595Full_9595BackgroundObjects1.length = 0;
gdjs.IntroCode.GDMerged_9595Full_9595BackgroundObjects2.length = 0;
gdjs.IntroCode.GDBridgeObjects1.length = 0;
gdjs.IntroCode.GDBridgeObjects2.length = 0;
gdjs.IntroCode.GDBridge_9595SupportObjects1.length = 0;
gdjs.IntroCode.GDBridge_9595SupportObjects2.length = 0;
gdjs.IntroCode.GDCave_9595EntranceObjects1.length = 0;
gdjs.IntroCode.GDCave_9595EntranceObjects2.length = 0;
gdjs.IntroCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.IntroCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.IntroCode.GDLamp_9595leftObjects1.length = 0;
gdjs.IntroCode.GDLamp_9595leftObjects2.length = 0;
gdjs.IntroCode.GDCave_9595Background_9595HoleObjects1.length = 0;
gdjs.IntroCode.GDCave_9595Background_9595HoleObjects2.length = 0;
gdjs.IntroCode.GDGrass_9595foregroundObjects1.length = 0;
gdjs.IntroCode.GDGrass_9595foregroundObjects2.length = 0;
gdjs.IntroCode.GDGrass_9595backgroundObjects1.length = 0;
gdjs.IntroCode.GDGrass_9595backgroundObjects2.length = 0;
gdjs.IntroCode.GDBush_9595BackgroundObjects1.length = 0;
gdjs.IntroCode.GDBush_9595BackgroundObjects2.length = 0;
gdjs.IntroCode.GDBush_9595Background_9595ShadowObjects1.length = 0;
gdjs.IntroCode.GDBush_9595Background_9595ShadowObjects2.length = 0;
gdjs.IntroCode.GDBush_9595foregroundObjects1.length = 0;
gdjs.IntroCode.GDBush_9595foregroundObjects2.length = 0;
gdjs.IntroCode.GDLamp_9595rightObjects1.length = 0;
gdjs.IntroCode.GDLamp_9595rightObjects2.length = 0;
gdjs.IntroCode.GDMushroomsObjects1.length = 0;
gdjs.IntroCode.GDMushroomsObjects2.length = 0;
gdjs.IntroCode.GDCave_9595Under_9595TileObjects1.length = 0;
gdjs.IntroCode.GDCave_9595Under_9595TileObjects2.length = 0;
gdjs.IntroCode.GDTile_959511Objects1.length = 0;
gdjs.IntroCode.GDTile_959511Objects2.length = 0;
gdjs.IntroCode.GDTile_95951Objects1.length = 0;
gdjs.IntroCode.GDTile_95951Objects2.length = 0;
gdjs.IntroCode.GDTile_959512Objects1.length = 0;
gdjs.IntroCode.GDTile_959512Objects2.length = 0;
gdjs.IntroCode.GDTile_959513Objects1.length = 0;
gdjs.IntroCode.GDTile_959513Objects2.length = 0;
gdjs.IntroCode.GDTile_959515Objects1.length = 0;
gdjs.IntroCode.GDTile_959515Objects2.length = 0;
gdjs.IntroCode.GDTile_959514Objects1.length = 0;
gdjs.IntroCode.GDTile_959514Objects2.length = 0;
gdjs.IntroCode.GDTile_959516Objects1.length = 0;
gdjs.IntroCode.GDTile_959516Objects2.length = 0;
gdjs.IntroCode.GDTile_959519Objects1.length = 0;
gdjs.IntroCode.GDTile_959519Objects2.length = 0;
gdjs.IntroCode.GDTile_959517Objects1.length = 0;
gdjs.IntroCode.GDTile_959517Objects2.length = 0;
gdjs.IntroCode.GDTile_959518Objects1.length = 0;
gdjs.IntroCode.GDTile_959518Objects2.length = 0;
gdjs.IntroCode.GDTile_95952Objects1.length = 0;
gdjs.IntroCode.GDTile_95952Objects2.length = 0;
gdjs.IntroCode.GDTile_959520Objects1.length = 0;
gdjs.IntroCode.GDTile_959520Objects2.length = 0;
gdjs.IntroCode.GDTile_959521Objects1.length = 0;
gdjs.IntroCode.GDTile_959521Objects2.length = 0;
gdjs.IntroCode.GDTile_959522Objects1.length = 0;
gdjs.IntroCode.GDTile_959522Objects2.length = 0;
gdjs.IntroCode.GDTile_959523Objects1.length = 0;
gdjs.IntroCode.GDTile_959523Objects2.length = 0;
gdjs.IntroCode.GDTile_959524Objects1.length = 0;
gdjs.IntroCode.GDTile_959524Objects2.length = 0;
gdjs.IntroCode.GDTile_959526Objects1.length = 0;
gdjs.IntroCode.GDTile_959526Objects2.length = 0;
gdjs.IntroCode.GDTile_959527Objects1.length = 0;
gdjs.IntroCode.GDTile_959527Objects2.length = 0;
gdjs.IntroCode.GDTile_959525Objects1.length = 0;
gdjs.IntroCode.GDTile_959525Objects2.length = 0;
gdjs.IntroCode.GDTile_959528Objects1.length = 0;
gdjs.IntroCode.GDTile_959528Objects2.length = 0;
gdjs.IntroCode.GDTile_959529Objects1.length = 0;
gdjs.IntroCode.GDTile_959529Objects2.length = 0;
gdjs.IntroCode.GDTile_959531Objects1.length = 0;
gdjs.IntroCode.GDTile_959531Objects2.length = 0;
gdjs.IntroCode.GDTile_959535Objects1.length = 0;
gdjs.IntroCode.GDTile_959535Objects2.length = 0;
gdjs.IntroCode.GDTile_959532Objects1.length = 0;
gdjs.IntroCode.GDTile_959532Objects2.length = 0;
gdjs.IntroCode.GDTile_959536Objects1.length = 0;
gdjs.IntroCode.GDTile_959536Objects2.length = 0;
gdjs.IntroCode.GDTile_959537Objects1.length = 0;
gdjs.IntroCode.GDTile_959537Objects2.length = 0;
gdjs.IntroCode.GDTile_95957Objects1.length = 0;
gdjs.IntroCode.GDTile_95957Objects2.length = 0;
gdjs.IntroCode.GDBoss_9595GolemObjects1.length = 0;
gdjs.IntroCode.GDBoss_9595GolemObjects2.length = 0;
gdjs.IntroCode.GDTile_95958Objects1.length = 0;
gdjs.IntroCode.GDTile_95958Objects2.length = 0;
gdjs.IntroCode.GDForest_9595Goblin_9595HogObjects1.length = 0;
gdjs.IntroCode.GDForest_9595Goblin_9595HogObjects2.length = 0;
gdjs.IntroCode.GDBatObjects1.length = 0;
gdjs.IntroCode.GDBatObjects2.length = 0;
gdjs.IntroCode.GDTile_95959Objects1.length = 0;
gdjs.IntroCode.GDTile_95959Objects2.length = 0;
gdjs.IntroCode.GDForest_9595GoblinObjects1.length = 0;
gdjs.IntroCode.GDForest_9595GoblinObjects2.length = 0;
gdjs.IntroCode.GDDark_9595GuardObjects1.length = 0;
gdjs.IntroCode.GDDark_9595GuardObjects2.length = 0;
gdjs.IntroCode.GDFrog_9595TongueObjects1.length = 0;
gdjs.IntroCode.GDFrog_9595TongueObjects2.length = 0;
gdjs.IntroCode.GDFrogObjects1.length = 0;
gdjs.IntroCode.GDFrogObjects2.length = 0;
gdjs.IntroCode.GDMushroomObjects1.length = 0;
gdjs.IntroCode.GDMushroomObjects2.length = 0;
gdjs.IntroCode.GDNecromancerObjects1.length = 0;
gdjs.IntroCode.GDNecromancerObjects2.length = 0;
gdjs.IntroCode.GDPlant_9595MutantObjects1.length = 0;
gdjs.IntroCode.GDPlant_9595MutantObjects2.length = 0;
gdjs.IntroCode.GDSkull_9595SlimeObjects1.length = 0;
gdjs.IntroCode.GDSkull_9595SlimeObjects2.length = 0;


return;

}

gdjs['IntroCode'] = gdjs.IntroCode;
